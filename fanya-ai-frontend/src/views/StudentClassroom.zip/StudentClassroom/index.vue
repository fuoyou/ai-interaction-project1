<template>
  <div class="student-app">
    <!-- 1. 顶部导航 -->
    <header class="header">
      <div class="header-left">
        <!-- 课件列表抽屉触发按钮 -->
        <el-button type="primary" plain round size="small" class="menu-btn" @click="showSidebarDrawer = true">
          <el-icon class="el-icon--left"><Expand /></el-icon> 课件列表
        </el-button>

        <el-button link @click="$router.push('/student')" class="back-btn hide-on-mobile">
          <el-icon><ArrowLeft /></el-icon> 退出
        </el-button>
        <el-divider direction="vertical" class="hide-on-mobile" />
        <span class="course-title">{{ currentFileName || '正在加载...' }}</span>
        
        <!-- 【功能】：可视化进度节点（小圆点），结合 NLP 闪烁状态 (移动端隐藏) -->
        <div class="knowledge-nodes hide-on-mobile" v-if="fullAiScript.length > 0">
          <div 
            v-for="(item, index) in Math.min(10, fullAiScript.length)"  
            :key="index"  
            :class="[
              'node-item', 
              { active: currentPage > (index * (fullAiScript.length / 10)) }, 
              { current: Math.floor(currentPage / (fullAiScript.length / 10)) === index },
              { 'warning-blink': Math.floor(currentPage / (fullAiScript.length / 10)) === index && isRhythmAdjusting }
            ]"
          >
            <el-tooltip :content="'阶段 ' + (index + 1)" placement="bottom"><span></span></el-tooltip>
          </div>
        </div>
      </div>

      <div class="header-right">
        <!-- 【功能】：可视化进度百分比 -->
        <el-tag v-if="fullAiScript.length > 0" type="primary" effect="light" round size="small" class="progress-tag">
          进度：{{ Math.round((currentPage / fullAiScript.length) * 100) }}%
        </el-tag>
        
        <el-tag type="success" effect="plain" round size="small" class="hide-on-mobile" style="margin-left: 10px;">
          <div class="tag-inner"><div class="dot"></div>AI 助教已就绪</div>
        </el-tag>
        
        <!-- 用户头像下拉菜单 -->
        <el-dropdown trigger="click" @command="handleUserCommand" class="user-dropdown">
          <div class="user-profile">
            <el-avatar 
              :size="28" 
              :src="userInfo.avatar || 'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png'" 
              class="clickable-avatar"
            />
            <span class="user-name-label hide-on-mobile">{{ userInfo.nickname || userInfo.username }}</span>
            <el-icon class="arrow-down hide-on-mobile"><ArrowDown /></el-icon>
          </div>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="profile">个人中心</el-dropdown-item>
              <el-dropdown-item command="history">学习记录</el-dropdown-item>
              <el-dropdown-item divided command="logout">退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </header>

    <!-- 课件列表抽屉 (direction="ltr" 表示从左侧滑出) -->
    <el-drawer 
      v-model="showSidebarDrawer" 
      title="课件列表" 
      direction="ltr"
      :size="isMobile ? '80%' : '320px'"
      class="course-drawer"
    >
      <div class="drawer-content">
        <div class="upload-box">
          <el-upload
            action="#"
            :auto-upload="false"
            :on-change="onFileChange"
            :show-file-list="false"
            accept=".pdf,.ppt,.pptx"
          >
            <el-button type="primary" class="upload-btn">
              <el-icon class="el-icon--left"><Upload /></el-icon>
              导入私有课件
            </el-button>
          </el-upload>
        </div>
        <div class="search-box">
          <el-input v-model="searchKeyword" placeholder="搜索课件..." clearable>
            <template #prefix>
              <el-icon><Search /></el-icon>
            </template>
          </el-input>
        </div>
        <div class="file-list" v-loading="loadingCourses">
          <el-empty v-if="!loadingCourses && filteredCourses.length === 0" description="暂无课件" :image-size="60" />
          <div
            v-for="item in filteredCourses"
            :key="item.id"
            :class="['file-list-item', { active: currentCourseId === item.id }]"
            @click="selectCourse(item)"
          >
            <div class="file-icon-wrapper">
              <span class="file-type-tag">{{ getFileType(item.courseName).toUpperCase() }}</span>
            </div>
            <div class="file-text-info">
              <div class="file-name">{{ item.courseName }}</div>
              <div class="file-meta">{{ item.teacherName || '我的课件' }}</div>
            </div>
          </div>
        </div>
      </div>
    </el-drawer>

    <!-- 2. 主体工作区 -->
    <main class="main-container" @mouseup="stopResize" @mousemove="handleResize">
      <div class="content-area">
        <!-- 左侧/中间部分：PDF 视图 -->
        <div v-if="showPdf" class="pdf-container" :style="pdfContainerStyle">
          <PdfViewer 
            v-loading="loading"
            :source="pdfSource" 
            :page="currentPage" 
            @changePage="handlePageChange" 
            @upload="showSidebarDrawer = true"
            @textSelected="handleTextSelected"
          />
        </div>
        
        <!-- PDF未显示时的占位提示 -->
        <div v-else class="pdf-placeholder" :style="pdfContainerStyle">
          <div class="placeholder-content">
            <el-icon :size="60" color="#909399"><Document /></el-icon>
            <p class="placeholder-text">请从左侧列表选择或上传课件</p>
            <el-button type="primary" size="large" round @click="showSidebarDrawer = true">
              <el-icon class="el-icon--left"><View /></el-icon>
              选择课件
            </el-button>
          </div>
        </div>
        
        <!-- 拖拽拉伸条 -->
        <div v-if="!isMobile" class="resizer" @mousedown="startResize">
          <div class="resizer-handle"></div>
        </div>

        <!-- 右侧部分：AI 对话框 (移动端时变为下方区域) -->
        <div class="right-panel" :style="rightPanelStyle">
          <!-- 拖拽把手区 -->
          <div class="dialog-drag-handle">
            <span class="dialog-title">AI 助教互动区</span>
            <el-button 
              link 
              size="small" 
              @click="showRhythmPanel = !showRhythmPanel"
              style="color: #2196F3; font-size: 14px; font-weight: 600;"
            >
              <el-icon><TrendCharts /></el-icon> {{ showRhythmPanel ? '隐藏诊断' : 'AI 诊断' }}
            </el-button>
          </div>
          
          <!-- 节奏诊断面板（可折叠） -->
          <transition name="slide-down">
            <div v-show="showRhythmPanel" class="rhythm-panel-container">
              <RhythmPanel 
                ref="rhythmPanelRef"
                :lessonId="currentCourseId" 
                @reviewSection="handleReviewSection"
              />
            </div>
          </transition>
          
          <!-- 聊天与讲解区 -->
          <AiSidebar 
            v-show="!showRhythmPanel"
            ref="aiSidebarRef"
            style="flex: 1; overflow: hidden; display: flex; flex-direction: column;"
            :width="'100%'" 
            v-model:mode="currentMode" 
            :script="currentScript" 
            :audioUrl="currentAudioUrl"
            :history="chatHistory" 
            :isChatLoading="isChatLoading"
            :courseId="currentCourseId"
            @sendMessage="onSendMessage" 
            @replay="startLecture" 
            @resolve="handleResolveSupplement" 
            @speakContent="handleSpeakContent"
            @jumpToPage="handleJumpToPage"
            @chatTextSelected="handleChatTextSelected"
          />
        </div>

        <!-- 数字人悬浮球（支持自由拖拽） -->
        <div 
          class="avatar-floating-ball" 
          :style="{ left: ballPos.x + 'px', top: ballPos.y + 'px', bottom: 'auto', right: 'auto' }"
          @mousedown="startDragBall"
          @touchstart="startDragBall"
          @click="toggleAvatarWindow"
        >
          <div class="ball-inner">
            <el-icon><VideoCamera /></el-icon>
          </div>
          <div v-if="isSpeakingGlobal" class="ball-pulse"></div>
        </div>

        <!-- 数字人浮窗（可拖动，无背景） -->
        <div 
          v-if="showAvatarWindow"
          class="avatar-floating-window"
          :style="{ left: isMobile ? '5%' : avatarWindowPos.x + 'px', top: isMobile ? '20%' : avatarWindowPos.y + 'px' }"
          @mousedown="!isMobile && startDragAvatarWindow($event)"
        >
          <div class="avatar-window-header" @mousedown.stop="!isMobile && startDragAvatarWindow($event)">
            <span class="avatar-window-title">AI 数字讲师</span>
            <el-icon class="close-btn" @click.stop="showAvatarWindow = false"><Close /></el-icon>
          </div>
          <div class="avatar-window-content">
            <DigitalAvatar 
              :script="currentScript" 
              :page="currentPage"
              :speakText="digitalHumanText" 
              :mode="currentMode"
              :totalPages="fullAiScript.length"
              @autoNextPage="handleAutoNextPage"
              @speaking="isSpeakingGlobal = $event"
            />
          </div>
        </div>
      </div>
    </main>

    <!-- 3. 个人中心弹窗 -->
    <el-dialog v-model="showProfileDialog" title="个人中心" :width="isMobile ? '90%' : '420px'" center align-center>
      <div class="profile-dialog-content">
        <div class="avatar-upload-section">
          <el-avatar :size="70" :src="profileForm.avatar || 'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png'" />
          <p class="role-badge">当前身份：学生</p>
        </div>
        <el-form :model="profileForm" label-width="80px" label-position="left">
          <el-form-item label="登录账号"><el-input v-model="profileForm.username" disabled /></el-form-item>
          <el-form-item label="用户昵称"><el-input v-model="profileForm.nickname" placeholder="请输入您的昵称" /></el-form-item>
          <el-form-item label="头像地址"><el-input v-model="profileForm.avatar" placeholder="请输入地址" /></el-form-item>
        </el-form>
      </div>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="showProfileDialog = false">取消</el-button>
          <el-button type="primary" :loading="saveLoading" @click="saveProfile">保存修改</el-button>
        </div>
      </template>
    </el-dialog>

    <!-- 4. 学习记录抽屉 -->
    <el-drawer v-model="showHistoryDrawer" title="学习互动足迹" direction="rtl" :size="isMobile ? '100%' : '400px'">
      <div v-loading="historyLoading">
        <el-empty v-if="historyList.length === 0" description="尚无互动记录" />
        <el-timeline v-else style="padding: 10px">
          <el-timeline-item v-for="(item, index) in historyList" :key="index" :timestamp="formatTime(item.createTime)" :type="item.action === 'CONTINUE' ? 'primary' : 'warning'" hollow>
            <div class="history-card">
              <div class="history-page-tag">第 {{ item.pageNum }} 页</div>
              <div class="history-q"><strong>问：</strong>{{ item.question }}</div>
              <div class="history-a"><p>{{ item.aiReply }}</p></div>
            </div>
          </el-timeline-item>
        </el-timeline>
      </div>
    </el-drawer>

    <!-- 5. 智能插旗考点弹窗 -->
    <CheckpointDialog 
      v-model="showCheckpointDialog" 
      :checkpoint="currentCheckpoint"
      @continue="handleCheckpointContinue"
    />
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, onUnmounted, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, ElNotification } from 'element-plus'
import { ArrowLeft, ArrowDown, Upload, Document, View, VideoCamera, Close, TrendCharts, Expand, Search } from '@element-plus/icons-vue'

// API 接口导入
import { diagnoseRhythm, getLearningHistory } from '@/api/rhythm' 
import { getCourseDetail, listMyStudentCourses, uploadCourse, chatWithAI } from '@/api/course' 
import { qaInteractStream } from '@/api/qa'
import { getProgressDetail, trackProgress } from '@/api/progress' 
import { updateUserProfile } from '@/api/user'

import PdfViewer from './components/PdfViewer.vue'
import AiSidebar from './components/AiSidebar.vue'
import DigitalAvatar from './components/DigitalAvatar.vue'
import CheckpointDialog from './components/CheckpointDialog.vue'
import RhythmPanel from './components/RhythmPanel.vue'

const route = useRoute()
const router = useRouter()

// --- 响应式适配状态 ---
const isMobile = ref(false)
const showSidebarDrawer = ref(false) // 课件抽屉

const checkMobile = () => {
  isMobile.value = window.innerWidth <= 768
}

// 动态计算 PDF 容器宽度
const pdfContainerStyle = computed(() => {
  if (isMobile.value) {
    return { width: '100%', height: '40%' } // 手机端上下分屏
  }
  return { width: `calc(100% - ${chatPanelWidth.value}px)` } // 桌面端左右分屏
})

// 动态计算右侧 AI 面板样式
const rightPanelStyle = computed(() => {
  if (isMobile.value) {
    return { width: '100%', height: '60%', margin: '0', borderRadius: '12px 12px 0 0' }
  }
  return { width: `${chatPanelWidth.value}px` } 
})

// --- 响应式状态 ---
const pdfSource = ref(null)
const currentPage = ref(1)
const currentFileName = ref('')
const chatPanelWidth = ref(420)
const currentMode = ref('lecture')
const loading = ref(false)
const isResizing = ref(false)
const isRhythmAdjusting = ref(false)
const currentScript = ref('')
const currentAudioUrl = ref('') 
const chatHistory = ref([{ role: 'ai', type: 'normal', content: '同学你好，欢迎进入 AI 智慧课堂。' }])

const fullAiScript = ref([])
const fullAudioScript = ref([]) 
const isChatLoading = ref(false) 
const qaSessionId = ref('')
const courseList = ref([])
const loadingCourses = ref(false)
const searchKeyword = ref('')
const currentCourseId = ref(null)

const userInfo = ref({ nickname: '', avatar: '', username: '' })
const showProfileDialog = ref(false)
const saveLoading = ref(false)
const profileForm = reactive({ username: '', nickname: '', avatar: '' })

const showHistoryDrawer = ref(false)
const historyList = ref([])
const historyLoading = ref(false)

const showRhythmPanel = ref(false)
const rhythmPanelRef = ref(null)
const aiSidebarRef = ref(null)

const showCheckpointDialog = ref(false)
const currentCheckpoint = ref({
  question: '',
  type: 'choice',
  options: [],
  correctAnswer: '',
  explanation: ''
})
const checkpoints = ref([]) 
const passedCheckpoints = ref(new Set()) 

// --- 数字人悬浮球（自由拖动）逻辑 ---
const showAvatarWindow = ref(false)
const isSpeakingGlobal = ref(false)
const ballPos = ref({ x: -999, y: -999 }) 
const isDraggingBall = ref(false)
let hasDraggedBall = false
let ballDragOffset = { x: 0, y: 0 }

const startDragBall = (e) => {
  isDraggingBall.value = true
  hasDraggedBall = false
  const clientX = e.clientX || e.touches[0].clientX
  const clientY = e.clientY || e.touches[0].clientY
  ballDragOffset.x = clientX - ballPos.value.x
  ballDragOffset.y = clientY - ballPos.value.y
  
  document.addEventListener('mousemove', onDragBall)
  document.addEventListener('mouseup', stopDragBall)
  document.addEventListener('touchmove', onDragBall, { passive: false })
  document.addEventListener('touchend', stopDragBall)
}

const onDragBall = (e) => {
  if (!isDraggingBall.value) return
  e.preventDefault() 
  hasDraggedBall = true
  const clientX = e.clientX || e.touches[0].clientX
  const clientY = e.clientY || e.touches[0].clientY
  let newX = clientX - ballDragOffset.x
  let newY = clientY - ballDragOffset.y

  const ballSize = 60
  newX = Math.max(0, Math.min(newX, window.innerWidth - ballSize))
  newY = Math.max(0, Math.min(newY, window.innerHeight - ballSize))
  
  ballPos.value = { x: newX, y: newY }
}

const stopDragBall = () => {
  isDraggingBall.value = false
  document.removeEventListener('mousemove', onDragBall)
  document.removeEventListener('mouseup', stopDragBall)
  document.removeEventListener('touchmove', onDragBall)
  document.removeEventListener('touchend', stopDragBall)
}

const toggleAvatarWindow = () => {
  if (!hasDraggedBall) {
    showAvatarWindow.value = !showAvatarWindow.value
  }
}

// --- 数字人浮窗拖动逻辑 ---
const avatarWindowPos = ref({ x: window.innerWidth - 400, y: 100 })
const isDraggingAvatarWindow = ref(false)
const dragStartPos = ref({ x: 0, y: 0 })

const startDragAvatarWindow = (e) => {
  if (isMobile.value) return 
  isDraggingAvatarWindow.value = true
  dragStartPos.value = {
    x: e.clientX - avatarWindowPos.value.x,
    y: e.clientY - avatarWindowPos.value.y
  }
  document.addEventListener('mousemove', onDragAvatarWindow)
  document.addEventListener('mouseup', stopDragAvatarWindow)
  e.preventDefault()
}

const onDragAvatarWindow = (e) => {
  if (!isDraggingAvatarWindow.value) return
  const newX = Math.max(0, Math.min(e.clientX - dragStartPos.value.x, window.innerWidth - 300))
  const newY = Math.max(0, Math.min(e.clientY - dragStartPos.value.y, window.innerHeight - 300))
  avatarWindowPos.value = { x: newX, y: newY }
}

const stopDragAvatarWindow = () => {
  isDraggingAvatarWindow.value = false
  document.removeEventListener('mousemove', onDragAvatarWindow)
  document.removeEventListener('mouseup', stopDragAvatarWindow)
}

const digitalHumanText = ref('')
const showPdf = ref(false)

const isPolling = ref(false)
let pollingTimer = null

const isPreviewableUrl = (url) => {
  if (!url) return false
  const lower = String(url).toLowerCase()
  return lower.endsWith('.pdf') || lower.endsWith('.pptx')
}

const startPollingForStudent = (courseId) => {
  if (pollingTimer) clearInterval(pollingTimer)
  isPolling.value = true
  
  pollingTimer = setInterval(async () => {
    if (currentCourseId.value !== courseId) {
      clearInterval(pollingTimer)
      isPolling.value = false
      return
    }
    try {
      const res = await getCourseDetail(courseId)
      const detailData = res.data || res
      if (detailData) {
        fullAiScript.value = detailData.aiScript || []
        fullAudioScript.value = detailData.audioScript || []
        updateCurrentScript()
        if (isPreviewableUrl(detailData.fileUrl) && !pdfSource.value) {
          pdfSource.value = `/api/v1/lesson/files/${detailData.fileUrl}`
          showPdf.value = true
        }
      }
      if (detailData.status === 3 || detailData.status === 9) {
        clearInterval(pollingTimer)
        isPolling.value = false
      }
    } catch (err) {
      clearInterval(pollingTimer)
      isPolling.value = false
    }
  }, 3000) 
}

const filteredCourses = computed(() => {
  if (!searchKeyword.value) return courseList.value
  const key = searchKeyword.value.toLowerCase()
  return courseList.value.filter(item => (item.courseName || '').toLowerCase().includes(key))
})

const getFileType = (fileName) => {
  if (!fileName) return 'other'
  const ext = fileName.split('.').pop().toLowerCase()
  return ['pdf'].includes(ext) ? 'pdf' : (['ppt', 'pptx'].includes(ext) ? 'ppt' : 'other')
}

const selectCourse = async (course) => {
  if (!course || !course.id) return
  window.speechSynthesis.cancel()
  if (pollingTimer) clearInterval(pollingTimer)
  isPolling.value = false

  currentCourseId.value = course.id
  currentFileName.value = course.courseName || ''
  loading.value = true
  showSidebarDrawer.value = false
  
  // 重置思维导图和知识图谱数据
  if (aiSidebarRef.value) {
    aiSidebarRef.value.resetGraphData()
  }
  
  try {
    const res = await getCourseDetail(course.id)
    const detailData = res.data || res
    const fileUrl = detailData.fileUrl || course.fileUrl
    if (!fileUrl) throw new Error('找不到文件路径')

    if (isPreviewableUrl(fileUrl)) {
      pdfSource.value = `/api/v1/lesson/files/${fileUrl}`
    } else {
      pdfSource.value = null
    }
    
    currentMode.value = 'lecture'
    
    try {
      const progressRes = await getProgressDetail(course.id)
      const progressData = progressRes.data
      if (progressData && progressData.currentSectionId) {
        const lastPage = parseInt(progressData.currentSectionId.replace('sec', ''))
        currentPage.value = lastPage || 1
      } else {
        currentPage.value = 1 
      }
    } catch (err) {
      currentPage.value = 1 
    }

    chatHistory.value =[{ role: 'ai', type: 'normal', content: `同学你好，正在为你解析《${currentFileName.value}》。` }]
    fullAiScript.value = detailData.aiScript || []
    fullAudioScript.value = detailData.audioScript || []
    checkpoints.value = detailData.checkpoints || []
    passedCheckpoints.value.clear() 

    updateCurrentScript()
    showPdf.value = !!pdfSource.value;
    
    const needsPoll = detailData.status === 0 || detailData.status === 1 || !isPreviewableUrl(fileUrl)
    if (needsPoll) {
      startPollingForStudent(course.id)
    }

  } catch (e) {
    ElMessage.error('该课件文件暂时无法预览')
  } finally {
    loading.value = false
  }
}

const updateCurrentScript = () => {
  if (fullAiScript.value.length > 0) {
    const currentSlide = fullAiScript.value.find(
      slide => slide.page === currentPage.value || slide.pageNum === currentPage.value
    )
    if (currentSlide && currentSlide.content) {
      currentScript.value = currentSlide.content
    } else {
      currentScript.value = `当前第 ${currentPage.value} 页无讲稿内容。`
    }
    const currentAudio = fullAudioScript.value.find(
      audio => audio.page === currentPage.value
    )
    currentAudioUrl.value = (currentAudio && currentAudio.audioUrl) ? currentAudio.audioUrl : ''
  } else {
    currentScript.value = "同学你好，AI 正在为你准备本页的深度解析，请稍等片刻。"
    currentAudioUrl.value = "/api/v1/lesson/audio/system_loading.mp3" 
  }
}

const handlePageChange = (delta) => { 
  if (typeof delta === 'number') {
    currentPage.value += delta
  }
  
  const checkpoint = checkpoints.value.find(cp => cp.pageNum === currentPage.value)
  if (checkpoint && !passedCheckpoints.value.has(checkpoint.id)) {
    window.speechSynthesis.cancel()
    currentMode.value = 'chat'
    digitalHumanText.value = ''
    currentCheckpoint.value = checkpoint
    showCheckpointDialog.value = true
    return
  }
  
  currentScript.value = ''
  currentAudioUrl.value = ''
  nextTick(() => {
    updateCurrentScript() 
  })
  
  if (currentCourseId.value) {
    trackProgress({
      courseId: currentCourseId.value,
      lessonId: currentCourseId.value,
      pageNum: currentPage.value,
      progressPercent: Math.round((currentPage.value / fullAiScript.value.length) * 100)
    }).catch(e => {})
  }
}

const handleAutoNextPage = () => {
  if (currentPage.value < fullAiScript.value.length) {
    handlePageChange(1);
  }
}

const handleCheckpointContinue = () => {
  passedCheckpoints.value.add(currentCheckpoint.value.id)
  showCheckpointDialog.value = false
  currentMode.value = 'lecture'
  
  nextTick(() => {
    updateCurrentScript();
  })
}

const startLecture = () => {
  window.speechSynthesis.cancel()
  const tempScript = currentScript.value
  const tempAudio = currentAudioUrl.value
  currentScript.value = ''
  currentAudioUrl.value = ''
  nextTick(() => {
    currentScript.value = tempScript
    currentAudioUrl.value = tempAudio
  })
}

const loadCourseList = async () => {
  loadingCourses.value = true
  try {
    const res = await listMyStudentCourses()
    courseList.value = Array.isArray(res.data) ? res.data : (Array.isArray(res) ? res :[])
    return courseList.value
  } catch (e) {
    ElMessage.error('课件列表刷新失败')
  } finally {
    loadingCourses.value = false
  }
}

const onFileChange = async (file) => {
  if (!file || !file.raw) return
  loading.value = true
  try {
    const res = await uploadCourse(file.raw)
    const newId = res.data?.id || res.data
    ElMessage.success('课件上传成功，正在准备预览...')
    const newList = await loadCourseList()
    const target = newList.find(c => String(c.id) === String(newId))
    if (target) {
      await selectCourse(target)
    } else if (newList.length > 0) {
      await selectCourse(newList[0]) 
    }
  } catch (e) {
    ElMessage.error('课件处理失败，请检查文件格式')
  } finally {
    loading.value = false
  }
}

onMounted(async () => {
  checkMobile()
  window.addEventListener('resize', checkMobile)
  
  ballPos.value = {
    x: window.innerWidth - 100,
    y: window.innerHeight - 150
  }

  const cachedUser = localStorage.getItem('userInfo')
  if (cachedUser) userInfo.value = JSON.parse(cachedUser)

  const list = await loadCourseList()
  const routeId = route.params.id
  if (routeId) {
    const target = list.find(c => String(c.id) === String(routeId))
    if (target) selectCourse(target)
  } else if (list.length > 0) {
    selectCourse(list[0])
  }
})

onUnmounted(() => {
  if (pollingTimer) clearInterval(pollingTimer)
  window.removeEventListener('resize', checkMobile)
})

const openProfile = () => {
  Object.assign(profileForm, { 
    username: userInfo.value.username || '未登录',
    nickname: userInfo.value.nickname,
    avatar: userInfo.value.avatar
  })
  showProfileDialog.value = true
}

const saveProfile = async () => {
  if (!profileForm.nickname.trim()) return ElMessage.warning('昵称不能为空')
  saveLoading.value = true
  try {
    await updateUserProfile({
      username: userInfo.value.username,
      nickname: profileForm.nickname,
      avatar: profileForm.avatar
    })
    Object.assign(userInfo.value, { nickname: profileForm.nickname, avatar: profileForm.avatar })
    localStorage.setItem('userInfo', JSON.stringify(userInfo.value))
    ElMessage.success('信息修改成功')
    showProfileDialog.value = false
  } finally {
    saveLoading.value = false
  }
}

const handleUserCommand = async (cmd) => {
  if (cmd === 'history') {
    showHistoryDrawer.value = true
    await loadLearningHistory()
  }
  else if (cmd === 'profile') openProfile();
  else if (cmd === 'logout') {
    localStorage.clear();
    router.push('/login');
  }
}

const loadLearningHistory = async () => {
  if (!currentCourseId.value) {
    ElMessage.warning('请先选择一个课件')
    return
  }
  
  historyLoading.value = true
  try {
    const res = await getLearningHistory(currentCourseId.value)
    historyList.value = res.data || []
  } catch (e) {
    historyList.value = []
  } finally {
    historyLoading.value = false
  }
}

const onSendMessage = async (text) => {
  if (!currentCourseId.value) return ElMessage.warning('请先选择一个课件')
  
  const historyQa = chatHistory.value
    .filter(msg => msg.role === 'user' || msg.role === 'ai')
    .slice(-6)
    .map(msg => ({ role: msg.role, content: msg.content }))

  chatHistory.value.push({ role: 'user', content: text })
  currentMode.value = 'chat'
  isChatLoading.value = true 
  
  try {
    const aiMsg = { role: 'ai', type: 'normal', content: '', audioUrl: '', streaming: true }
    chatHistory.value.push(aiMsg)
    const aiMsgIndex = chatHistory.value.length - 1
    let donePayload = null

    await qaInteractStream(
      { courseId: currentCourseId.value, lessonId: currentCourseId.value, pageNum: currentPage.value, sessionId: qaSessionId.value, question: text, historyQa, currentPageContent: currentScript.value },
      {
        onMeta: (meta) => { if (meta?.sessionId) qaSessionId.value = meta.sessionId },
        onDelta: (delta) => { chatHistory.value[aiMsgIndex].content += delta?.text || '' },
        onDone: (payload) => { donePayload = payload },
        onError: (err) => { throw new Error(err?.message || '流式回答失败') }
      }
    )

    const data = donePayload || {}
    chatHistory.value[aiMsgIndex].streaming = false
    chatHistory.value[aiMsgIndex].audioUrl = data.audioUrl || ''

    if (data.answerContent && !chatHistory.value[aiMsgIndex].content) {
      chatHistory.value[aiMsgIndex].content = data.answerContent
    }
    if (data.sessionId) qaSessionId.value = data.sessionId

    if (!chatHistory.value[aiMsgIndex].content || !chatHistory.value[aiMsgIndex].content.trim()) {
      chatHistory.value.splice(aiMsgIndex, 1)
    } else {
      const userMsg = chatHistory.value.find(m => m.role === 'user' && m.sourceType === 'text-selection' && m.sourcePage === currentPage.value)
      if (userMsg) chatHistory.value[aiMsgIndex].sourcePage = userMsg.sourcePage
    }

    if (data.understandingLevel === 'none') {
      const suppText = data.supplementContent || "看来这里有点难，没关系，我们换个简单的方式再讲一遍..."
      chatHistory.value.push({ role: 'ai', type: 'supplement', content: suppText, resolved: false })
      isRhythmAdjusting.value = true
      
      if (data.adjustedScript && data.adjustedScript.trim()) {
        currentScript.value = data.adjustedScript
      }
      
      setTimeout(() => {
        const chatArea = document.querySelector('.chat-area')
        if (chatArea) chatArea.scrollTop = chatArea.scrollHeight
      }, 100)
    }
  } catch (e) { 
    const lastMsg = chatHistory.value[chatHistory.value.length - 1]
    if (lastMsg && lastMsg.role === 'ai' && lastMsg.streaming) chatHistory.value.pop()
    
    try {
      const res = await chatWithAI({ courseId: currentCourseId.value, pageNum: currentPage.value, question: text, historyQa, currentPageContent: currentScript.value })
      const data = res.data || res
      chatHistory.value.push({ role: 'ai', type: 'normal', content: data.answerContent || '系统忙，请稍后再试', audioUrl: data.audioUrl })
      if (data.sessionId) qaSessionId.value = data.sessionId
    } catch {
      ElMessage.error('AI 响应异常')
    }
  } finally {
    isChatLoading.value = false 
  }
}

const handleResolveSupplement = (msgIndex) => {
    chatHistory.value[msgIndex].resolved = true
    isRhythmAdjusting.value = false
    ElNotification({ title: '节奏同步成功', message: '已为您切换回原讲授节点，继续讲解。', type: 'success', duration: 2000 })
    currentMode.value = 'lecture'
    
    if (currentScript.value && currentScript.value.trim()) {
        nextTick(() => { handleSpeakContent(currentScript.value) })
    }
    if (rhythmPanelRef.value) rhythmPanelRef.value.refreshDiagnosis()
}

const handleSpeakContent = (content) => {
  digitalHumanText.value = content;
}

const formatTime = (t) => t ? new Date(t).toLocaleString() : ''

const startResize = () => { if (!isMobile.value) isResizing.value = true }
const handleResize = (e) => {
  if (!isResizing.value || isMobile.value) return
  const w = window.innerWidth - e.clientX
  if (w > 300 && w < 800) chatPanelWidth.value = w
}
const stopResize = () => { isResizing.value = false }

const handleReviewSection = (sectionId) => {
  try {
    const pageNum = parseInt(sectionId.replace('sec', ''))
    if (pageNum && pageNum > 0 && pageNum <= fullAiScript.value.length) {
      const delta = pageNum - currentPage.value
      handlePageChange(delta)
      ElMessage.success(`已跳转到第 ${pageNum} 页`)
      showRhythmPanel.value = false
    }
  } catch (e) {
    ElMessage.warning('无法跳转到该章节')
  }
}

const handleTextSelected = ({ text, page, isFormula }) => {
  const cleanText = text.replace(/\s+/g, ' ').trim()
  let question = isFormula ? `请详细解释第${page}页中的这个公式的含义和应用：\n\n${cleanText}` : `请解释第${page}页中的这段内容：\n\n${cleanText}`
  onSendMessage(question)
  const lastUserMsg = chatHistory.value.filter(m => m.role === 'user').pop()
  if (lastUserMsg) {
    lastUserMsg.sourceType = isFormula ? 'formula-selection' : 'text-selection'
    lastUserMsg.sourcePage = page
    lastUserMsg.sourceText = text
  }
  ElMessage.success(isFormula ? '已选中公式并生成提问' : '已自动生成提问')
}

const handleJumpToPage = (pageNum) => {
  if (pageNum && pageNum > 0 && pageNum <= fullAiScript.value.length) {
    const delta = pageNum - currentPage.value
    handlePageChange(delta)
    ElMessage.success(`已跳转到第 ${pageNum} 页`)
  } else {
    ElMessage.warning('页码超出范围')
  }
}

const handleChatTextSelected = ({ text, originalMessage }) => {
  const hasFormula = text.includes('$')
  let question = hasFormula ? `请详细解释这个公式的含义和应用：${text}` : `请进一步解释："${text.substring(0, 100)}${text.length > 100 ? '...' : ''}"`
  onSendMessage(question)
  ElMessage.success('已生成追问')
}
</script>

<style scoped>
.student-app { 
  position: fixed; 
  inset: 0; 
  display: flex; 
  flex-direction: column; 
  overflow: hidden; 
  background: linear-gradient(135deg, #E3F2FD 0%, #F5F9FF 50%, #F0F5FF 100%); 
}

:deep(.el-button) {
  border-radius: 20px;
  transition: all 0.3s ease;
}
:deep(.el-button--primary:not(.is-plain)) {
  background: linear-gradient(135deg, #2196F3 0%, #1976D2 100%);
  border: none;
  box-shadow: 0 4px 10px rgba(33, 150, 243, 0.3);
}
:deep(.el-button--primary:not(.is-plain):hover) {
  transform: translateY(-2px);
  box-shadow: 0 6px 15px rgba(33, 150, 243, 0.4);
}

.header { 
  height: 54px; 
  background: linear-gradient(90deg, #FFFFFF 0%, #F8FBFE 100%); 
  backdrop-filter: blur(4px); 
  border-bottom: 1px solid rgba(33, 150, 243, 0.15); 
  display: flex; justify-content: space-between; align-items: center; padding: 0 20px; flex-shrink: 0;
  box-shadow: 0 2px 6px rgba(33, 150, 243, 0.08);
  z-index: 10;
}
.header-left { display: flex; align-items: center; gap: 10px; }
.menu-btn { font-weight: 600; }

.knowledge-nodes { display: flex; gap: 6px; margin-left: 15px; }
.node-item { width: 8px; height: 8px; background: rgba(33, 150, 243, 0.2); border-radius: 50%; transition: all 0.3s; cursor: pointer; }
.node-item.active { background: #64B5F6; }
.node-item.current { background: #2196F3; transform: scale(1.3); box-shadow: 0 0 8px rgba(33, 150, 243, 0.5); }
.node-item.warning-blink {
  background: #FFA726 !important; 
  animation: blink-orange 1.2s infinite ease-in-out;
  box-shadow: 0 0 12px rgba(255, 167, 38, 0.6);
}
@keyframes blink-orange {
  0% { opacity: 1; transform: scale(1.3); }
  50% { opacity: 0.4; transform: scale(1); }
  100% { opacity: 1; transform: scale(1.3); }
}

.course-title { font-size: 14px; font-weight: bold; color: #1565C0; margin-left: 5px;}
.header-right { display: flex; align-items: center; gap: 10px; }
.user-profile { display: flex; align-items: center; gap: 8px; cursor: pointer; outline: none; transition: all 0.3s; padding: 4px 12px; border-radius: 6px; }
.user-profile:hover { background: rgba(33, 150, 243, 0.1); box-shadow: 0 2px 4px rgba(33, 150, 243, 0.1); }
.user-name-label { font-size: 13px; color: #1976D2; font-weight: 500; }
.arrow-down { color: #64B5F6; }

.main-container { flex: 1; display: flex; overflow: hidden; position: relative; }
.content-area { flex: 1; display: flex; overflow: hidden; position: relative; width: 100%;}

.drawer-content { display: flex; flex-direction: column; height: 100%; padding: 10px; }
.upload-box { margin-bottom: 15px; }
.upload-btn { width: 100%; }
.search-box { margin-bottom: 12px; }
.file-list { flex: 1; overflow-y: auto; display: flex; flex-direction: column; gap: 10px; padding: 0 4px 4px; scrollbar-width: thin; scrollbar-color: rgba(33, 150, 243, 0.3) transparent; }

.file-list::-webkit-scrollbar {
  width: 6px;
}

.file-list::-webkit-scrollbar-track {
  background: transparent;
}

.file-list::-webkit-scrollbar-thumb {
  background: rgba(33, 150, 243, 0.3);
  border-radius: 3px;
}

.file-list::-webkit-scrollbar-thumb:hover {
  background: rgba(33, 150, 243, 0.5);
}
.file-list-item { 
  background: rgba(255, 255, 255, 0.95); border-radius: 8px; padding: 12px; cursor: pointer; display: flex; align-items: flex-start; gap: 12px; border: 1px solid rgba(33, 150, 243, 0.15); transition: all 0.3s;
}
.file-list-item:hover { 
  background: rgba(255, 255, 255, 1); border-color: rgba(33, 150, 243, 0.3); box-shadow: 0 4px 12px rgba(33, 150, 243, 0.1); transform: translateX(2px);
}
.file-list-item.active { 
  background: rgba(33, 150, 243, 0.08); border-color: #2196F3; box-shadow: 0 4px 12px rgba(33, 150, 243, 0.15);
}
.file-type-tag { font-size: 11px; padding: 3px 8px; border-radius: 4px; background: rgba(33, 150, 243, 0.1); color: #2196F3; font-weight: 600; }
.file-name { font-size: 14px; font-weight: 600; color: #1565C0; word-break: break-word; white-space: normal; line-height: 1.4; }
.file-meta { font-size: 12px; color: #64B5F6; margin-top: 4px;}

.pdf-container { flex-shrink: 0; height: 100%; overflow: hidden; background: transparent; display: flex; flex-direction: column; }
.pdf-placeholder { flex: 1; display: flex; align-items: center; justify-content: center; background: transparent; height: 100%; }
.placeholder-content { text-align: center; display: flex; flex-direction: column; align-items: center; gap: 20px; }
.placeholder-text { font-size: 16px; color: #666; margin: 0; }

.resizer { width: 8px; background: transparent; cursor: col-resize; position: relative; flex-shrink: 0; z-index: 5;}
.resizer:hover { background: rgba(33, 150, 243, 0.15); }
.resizer-handle { width: 4px; height: 40px; background: #64B5F6; position: absolute; top: 50%; left: 2px; transform: translateY(-50%); border-radius: 4px;}

.right-panel { 
  height: 100%; background: #FFFFFF; backdrop-filter: blur(12px); border-left: 1px solid rgba(33, 150, 243, 0.15); box-shadow: -4px 0 16px rgba(33, 150, 243, 0.08); display: flex; flex-direction: column; flex-shrink: 0; overflow: hidden; transition: width 0.3s;
}
.dialog-drag-handle {
  background: #FFFFFF; padding: 12px 16px; display: flex; align-items: center; justify-content: space-between; gap: 8px; user-select: none; flex-shrink: 0; margin-bottom: 0; border-bottom: 1px solid rgba(33, 150, 243, 0.15);
}
.dialog-title { color: #2196F3; font-size: 14px; font-weight: 600; flex: 1; }
.rhythm-panel-container { 
  flex: 1;
  overflow-y: auto; 
  border-bottom: none;
  display: flex;
  flex-direction: column;
}
.slide-down-enter-active, .slide-down-leave-active { transition: all 0.3s ease; max-height: 400px; }
.slide-down-enter-from, .slide-down-leave-to { max-height: 0; opacity: 0; overflow: hidden; }

.avatar-floating-ball {
  position: fixed; width: 60px; height: 60px; border-radius: 50%; background: linear-gradient(135deg, #2196F3 0%, #64B5F6 100%); box-shadow: 0 4px 16px rgba(33, 150, 243, 0.4); z-index: 9999; cursor: grab; display: flex; align-items: center; justify-content: center; transition: transform 0.2s, box-shadow 0.2s; touch-action: none;
}
.avatar-floating-ball:active { cursor: grabbing; transform: scale(0.95); }
.avatar-floating-ball:hover { box-shadow: 0 6px 20px rgba(33, 150, 243, 0.5); }
.ball-inner { color: #fff; font-size: 26px; display: flex; align-items: center; justify-content: center; user-select: none; pointer-events: none;}
.ball-pulse {
  position: absolute; width: 100%; height: 100%; border-radius: 50%; border: 2px solid rgba(33, 150, 243, 0.8); animation: pulse-ring 1.5s infinite; pointer-events: none;
}
@keyframes pulse-ring {
  0% { transform: scale(1); opacity: 1; }
  100% { transform: scale(1.4); opacity: 0; }
}

.avatar-floating-window {
  position: fixed; width: 380px; height: 550px; background: transparent; border-radius: 12px; z-index: 10000; display: flex; flex-direction: column; box-shadow: none;
}
.avatar-window-header { background: transparent; padding: 0; display: none; justify-content: space-between; align-items: center; cursor: move; user-select: none; flex-shrink: 0; }
.avatar-window-title { color: #fff; font-size: 14px; font-weight: 600; }
.close-btn { color: #fff; cursor: pointer; font-size: 18px; transition: color 0.3s; }
.close-btn:hover { color: #f0f0f0; }
.avatar-window-content { flex: 1; background: transparent; border-radius: 12px; overflow: hidden; }

.history-card { 
  background: rgba(255, 255, 255, 0.95); padding: 15px; border-radius: 8px; border: 1px solid rgba(33, 150, 243, 0.15); box-shadow: 0 2px 4px rgba(33, 150, 243, 0.08);
}
.history-q { font-size: 13px; font-weight: bold; margin-bottom: 8px; color: #1565C0; }
.history-a { font-size: 12px; color: #1976D2; line-height: 1.6; }

@media screen and (max-width: 768px) {
  .hide-on-mobile { display: none !important; }
  .header { padding: 0 10px; }
  .course-title { font-size: 13px; max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .progress-tag { margin-left: 5px !important; }
  .user-dropdown { margin-left: 5px !important; }
  .content-area { flex-direction: column; }
  .avatar-floating-window { width: 90vw !important; height: 60vh !important; max-height: 500px; }
  .avatar-floating-ball { width: 50px; height: 50px; }
  .ball-inner { font-size: 22px; }
  .dialog-drag-handle { padding: 10px 12px; margin-bottom: 0; }
  .right-panel { gap: 0; }
}
</style>