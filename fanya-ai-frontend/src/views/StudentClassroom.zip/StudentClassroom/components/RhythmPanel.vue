<template>
  <div class="rhythm-panel">
    <!-- 理解度仪表盘 -->
    <div class="understanding-gauge glass-card-primary">
      <div class="gauge-header">
        <span class="gauge-title">📊 学习理解度</span>
        <el-tooltip content="基于AI分析您的提问和回答，评估当前理解程度" placement="top">
          <el-icon class="info-icon"><QuestionFilled /></el-icon>
        </el-tooltip>
      </div>
      
      <div class="gauge-body">
        <el-progress 
          type="dashboard" 
          :percentage="understandingScore" 
          :color="getScoreColor(understandingScore)"
          :width="120"
        >
          <template #default="{ percentage }">
            <span class="percentage-value">{{ percentage }}</span>
            <span class="percentage-label">分</span>
          </template>
        </el-progress>
        
        <div class="score-label">{{ getScoreLabel(understandingScore) }}</div>
      </div>
    </div>

    <!-- 理解统计 -->
    <div class="understanding-stats">
      <div class="stat-item glass-item" v-for="(value, key) in understandingStats" :key="key">
        <div class="stat-icon" :class="`stat-${key}`">
          <span v-if="key === 'full'">✓</span>
          <span v-else-if="key === 'partial'">~</span>
          <span v-else>✗</span>
        </div>
        <div class="stat-info">
          <div class="stat-label">{{ getStatLabel(key) }}</div>
          <div class="stat-value">{{ value }} 次</div>
        </div>
      </div>
    </div>

    <!-- 节奏建议 -->
    <div class="rhythm-suggestions glass-section" v-if="suggestions.length > 0">
      <div class="suggestions-header">💡 智能建议</div>
      <div class="suggestion-list">
        <div 
          v-for="(suggestion, index) in suggestions" 
          :key="index"
          class="suggestion-item glass-item"
          :class="`suggestion-${suggestion.type}`"
        >
          <div class="suggestion-icon">
            <el-icon v-if="suggestion.type === 'slow_down'"><Warning /></el-icon>
            <el-icon v-else-if="suggestion.type === 'speed_up'"><Promotion /></el-icon>
            <el-icon v-else><SuccessFilled /></el-icon>
          </div>
          <div class="suggestion-content">
            <div class="suggestion-message">{{ suggestion.message }}</div>
            <div class="suggestion-actions" v-if="suggestion.sections && suggestion.sections.length > 0">
              <el-button 
                size="small" 
                type="primary" 
                plain
                @click="handleReviewSection(suggestion.sections[0])"
              >
                立即复习
              </el-button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 困惑章节 -->
    <div class="confused-sections glass-section" v-if="confusedSections.length > 0">
      <div class="section-header">
        <span>🤔 需要加强的章节</span>
        <el-tag size="small" type="warning" effect="plain">{{ confusedSections.length }}</el-tag>
      </div>
      <div class="section-list">
        <div 
          v-for="section in confusedSections.slice(0, 5)" 
          :key="section"
          class="section-item confused glass-item"
          @click="handleReviewSection(section)"
        >
          <span class="section-name">{{ section }}</span>
          <el-icon class="section-arrow"><ArrowRight /></el-icon>
        </div>
      </div>
    </div>

    <!-- 已掌握章节 -->
    <div class="mastered-sections glass-section" v-if="masteredSections.length > 0">
      <div class="section-header">
        <span>✅ 已掌握的章节</span>
        <el-tag size="small" type="success" effect="plain">{{ masteredSections.length }}</el-tag>
      </div>
      <div class="section-list">
        <div v-for="section in masteredSections.slice(0, 3)" :key="section" class="section-item mastered glass-item">
          <span class="section-name">{{ section }}</span>
          <el-icon class="section-check"><Check /></el-icon>
        </div>
      </div>
    </div>

    <!-- 刷新按钮 -->
    <div class="panel-footer">
      <el-button size="small" :loading="loading" @click="refreshDiagnosis" style="width: 100%;" plain class="refresh-btn">
        <el-icon><Refresh /></el-icon> 重新评估节奏
      </el-button>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { QuestionFilled, Warning, Promotion, SuccessFilled, ArrowRight, Check, Refresh } from '@element-plus/icons-vue'
import { diagnoseRhythm } from '@/api/progress'

const props = defineProps({ lessonId: { type: [String, Number], required: true } })
const emit = defineEmits(['reviewSection'])
const loading = ref(false)
const understandingScore = ref(50)
const understandingStats = ref({ full: 0, partial: 0, none: 0 })
const suggestions = ref([])
const confusedSections = ref([])
const masteredSections = ref([])

const getScoreColor = (score) => (score >= 80 ? '#67c23a' : score >= 60 ? '#2196F3' : '#f56c6c')
const getScoreLabel = (score) => (score >= 80 ? '掌握良好' : score >= 60 ? '基本理解' : score >= 40 ? '需要加强' : '理解困难')
const getStatLabel = (key) => ({ full: '完全理解', partial: '部分理解', none: '未理解' }[key] || key)

const handleReviewSection = (section) => emit('reviewSection', section)

const refreshDiagnosis = async () => {
  if (!props.lessonId) return ElMessage.warning('请先选择课件')
  loading.value = true
  try {
    const res = await diagnoseRhythm(props.lessonId)
    const data = res.data || res
    understandingScore.value = data.understandingScore || 50
    understandingStats.value = data.understandingStats || { full: 0, partial: 0, none: 0 }
    suggestions.value = data.suggestions || []
    confusedSections.value = data.confusedSections || []
    masteredSections.value = data.masteredSections || []
    ElMessage.success('诊断完成')
  } catch (error) {
    ElMessage.error('诊断失败')
  } finally {
    loading.value = false
  }
}

onMounted(() => props.lessonId && refreshDiagnosis())
defineExpose({ refreshDiagnosis })
</script>

<style scoped>
.rhythm-panel { background: transparent; padding: 20px; display: flex; flex-direction: column; gap: 20px; }

/* 核心：蓝色渐变玻璃拟态 */
.glass-card-primary {
  background: linear-gradient(135deg, rgba(33, 150, 243, 0.8) 0%, rgba(100, 181, 246, 0.8) 100%);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  box-shadow: 0 8px 24px rgba(33, 150, 243, 0.2);
  border-radius: 12px;
  padding: 20px;
  color: #fff;
}

.gauge-body { display: flex; flex-direction: column; align-items: center; gap: 10px; }
.percentage-value { font-size: 28px; font-weight: bold; color: #fff; }

.understanding-stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }
.glass-section {
  background: rgba(255, 255, 255, 0.7);
  backdrop-filter: blur(6px);
  border: 1px solid rgba(33, 150, 243, 0.15);
  border-radius: 10px;
  padding: 15px;
}
.glass-item {
  background: rgba(255, 255, 255, 0.8);
  border: 1px solid rgba(33, 150, 243, 0.2);
  border-radius: 8px;
  padding: 12px;
  transition: all 0.3s;
}
.glass-item:hover { 
  background: rgba(255, 255, 255, 0.95);
  box-shadow: 0 2px 8px rgba(33, 150, 243, 0.1);
}

/* 统计图标色调统一 */
.stat-icon.stat-full { background: rgba(103, 194, 58, 0.15); color: #67c23a; }
.stat-icon.stat-partial { background: rgba(33, 150, 243, 0.15); color: #2196F3; }
.stat-icon.stat-none { background: rgba(245, 108, 108, 0.15); color: #f56c6c; }

.suggestion-item { display: flex; gap: 12px; border-left: 3px solid #2196F3; }
.suggestion-icon { font-size: 20px; color: #2196F3; }

.section-item.confused { border-left: 3px solid #f56c6c; }
.section-item.mastered { border-left: 3px solid #67c23a; }

.refresh-btn {
  border-color: #2196F3 !important;
  color: #2196F3 !important;
}
.refresh-btn:hover { background: rgba(33, 150, 243, 0.1) !important; }

/* 移动端适配 */
@media screen and (max-width: 768px) {
  .rhythm-panel { padding: 10px; }
  .understanding-stats { grid-template-columns: 1fr; }
}
</style>
