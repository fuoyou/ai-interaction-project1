<template>
  <div class="input-area">
    <!-- 讲解模式：快捷操作区 -->
    <div class="quick-actions" v-if="mode === 'lecture'">
      <el-button class="glass-btn" round size="small" @click="$emit('replay')">
        <el-icon><RefreshLeft /></el-icon> 重讲本页
      </el-button>
      <el-button class="glass-btn-primary" round size="small" type="primary" @click="$emit('switchToChat')">
        <el-icon><QuestionFilled /></el-icon> 我有疑问
      </el-button>
    </div>
    
    <!-- 问答模式：预设问题 + 输入框 -->
    <div v-else class="chat-input-wrapper">
      <!-- 预设问题：移动端可以横向滚动 -->
      <div class="preset-questions">
        <el-tag 
          v-for="(question, index) in presetQuestions" 
          :key="index"
          class="question-tag glass-tag"
          @click="handlePresetQuestion(question)"
          effect="plain"
          size="small"
        >
          {{ question }}
        </el-tag>
      </div>
      
      <!-- 输入框区域 -->
      <div class="input-box-wrapper">
        <!-- 语音录制遮罩 -->
        <div v-if="isRecording" class="recording-overlay glass-overlay">
          <div class="recording-wave"></div>
          <p>正在聆听...</p>
          <span class="recording-hint">松开结束</span>
        </div>

        <el-input 
          v-model="internalValue" 
          :placeholder="isRecording ? '正在识别...' : placeholder" 
          @keyup.enter="handleSend"
          class="input-field glass-input"
        >
          <template #prefix>
            <el-tooltip content="长按录音提问" placement="top">
              <el-icon 
                class="mic-icon" 
                :class="{ 'is-active': isRecording }"
                @mousedown="startRealRecording" 
                @mouseup="stopRealRecording"
                @mouseleave="stopRealRecording"
                @touchstart="startRealRecording"
                @touchend="stopRealRecording"
              >
                <Microphone />
              </el-icon>
            </el-tooltip>
          </template>
          <template #suffix>
            <el-button class="send-btn" circle type="primary" @click="handleSend" :disabled="!internalValue.trim()">
              <el-icon><Position /></el-icon>
            </el-button>
          </template>
        </el-input>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, watch, onMounted } from 'vue'
import { RefreshLeft, QuestionFilled, Microphone, Position } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'

const props = defineProps(['modelValue', 'mode', 'placeholder'])
const emit = defineEmits(['update:modelValue', 'send', 'replay', 'switchToChat'])

const internalValue = ref(props.modelValue)
const isRecording = ref(false)

const presetQuestions = ref([
  '这个知识点能再讲详细一点吗？',
  '能举个例子说明吗？',
  '这一页的重点是什么？',
  '我不太理解，能换个说法吗？'
])

let recognition = null
onMounted(() => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
  if (SpeechRecognition) {
    recognition = new SpeechRecognition()
    recognition.continuous = false
    recognition.lang = 'zh-CN'
    recognition.interimResults = true
    recognition.onresult = (event) => {
      internalValue.value = event.results[event.results.length - 1][0].transcript
    }
    recognition.onend = () => { isRecording.value = false }
  }
})

watch(() => props.modelValue, (val) => internalValue.value = val)
watch(internalValue, (val) => emit('update:modelValue', val))

const handleSend = () => { if (internalValue.value.trim()) emit('send') }
const handlePresetQuestion = (question) => { internalValue.value = question; emit('send') }

const startRealRecording = (e) => {
  e.preventDefault()
  if (!recognition) return ElMessage.warning('不支持语音识别')
  isRecording.value = true
  internalValue.value = ''
  recognition.start()
}
const stopRealRecording = () => { if (recognition && isRecording.value) recognition.stop() }
</script>

<style scoped>
.input-area { 
  padding: 16px; 
  background: linear-gradient(180deg, rgba(33, 150, 243, 0.08) 0%, rgba(240, 245, 255, 0.5) 100%);
  backdrop-filter: blur(8px);
  border-top: 1px solid rgba(33, 150, 243, 0.15); 
  flex-shrink: 0; 
}

/* 按钮组样式 */
.quick-actions { 
  display: flex; 
  gap: 10px; 
  justify-content: center;
  flex-wrap: wrap;
}

.glass-btn {
  background: #FFFFFF !important;
  border: 1px solid rgba(33, 150, 243, 0.2) !important;
  color: #1976D2 !important;
  font-weight: 500;
  transition: all 0.3s;
}

.glass-btn:hover { 
  background: rgba(33, 150, 243, 0.08) !important; 
  color: #2196F3 !important;
  border-color: #2196F3 !important;
  box-shadow: 0 2px 8px rgba(33, 150, 243, 0.12);
}

.glass-btn-primary {
  background: linear-gradient(90deg, #2196F3 0%, #64B5F6 100%) !important;
  border: none !important;
  box-shadow: 0 4px 12px rgba(33, 150, 243, 0.28) !important;
  font-weight: 600;
}

.glass-btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 18px rgba(33, 150, 243, 0.35) !important;
}

/* 预设问题 */
.preset-questions{
  display: flex; 
  overflow-x: auto; 
  gap: 8px; 
  margin-bottom: 12px; 
  padding-bottom: 5px; 
  scrollbar-width: none;
}
.preset-questions::-webkit-scrollbar { display: none; }

.glass-tag {
  cursor: pointer; 
  white-space: nowrap;
  border: 1px solid rgba(33, 150, 243, 0.2) !important;
  color: #1976D2 !important;
  background: #FFFFFF !important;
  backdrop-filter: blur(2px);
  transition: all 0.3s;
}

.glass-tag:hover { 
  border-color: #2196F3 !important; 
  color: #2196F3 !important; 
  background: rgba(33, 150, 243, 0.08) !important;
  box-shadow: 0 2px 6px rgba(33, 150, 243, 0.1);
}

/* 输入框：蓝色企业风格 */
.glass-input :deep(.el-input__wrapper) { 
  background: #FFFFFF;
  backdrop-filter: blur(2px);
  border-radius: 20px; 
  padding: 5px 15px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.03), 0 0 0 1px rgba(33, 150, 243, 0.2) inset !important; 
  transition: all 0.3s;
}

.glass-input :deep(.el-input__wrapper.is-focus) {
  box-shadow: 0 4px 12px rgba(33, 150, 243, 0.15), 0 0 0 1.5px #2196F3 inset !important;
  background: #F8FBFE !important;
}

/* 麦克风图标 */
.mic-icon { 
  cursor: pointer; 
  color: #64B5F6; 
  font-size: 20px; 
  transition: all 0.2s; 
  padding: 5px; 
}

.mic-icon:hover { 
  color: #2196F3;
  transform: scale(1.1);
}

.mic-icon.is-active { 
  color: #2196F3; 
  transform: scale(1.2);
  animation: mic-pulse 1s infinite;
}

@keyframes mic-pulse {
  0%, 100% { transform: scale(1.2); }
  50% { transform: scale(1.3); }
}

.send-btn { 
  background: linear-gradient(90deg, #2196F3 0%, #64B5F6 100%) !important; 
  border: none !important;
  box-shadow: 0 2px 6px rgba(33, 150, 243, 0.2) !important;
}

.send-btn:hover {
  box-shadow: 0 4px 12px rgba(33, 150, 243, 0.3) !important;
}

/* 录音遮罩 */
.glass-overlay {
  position: absolute; 
  bottom: 80px; 
  left: 50%; 
  transform: translateX(-50%);
  padding: 20px; 
  border-radius: 12px; 
  width: 140px; 
  text-align: center;
  background: linear-gradient(135deg, rgba(21, 101, 192, 0.95) 0%, rgba(33, 150, 243, 0.85) 100%);
  backdrop-filter: blur(10px);
  color: #fff;
  box-shadow: 0 8px 24px rgba(33, 150, 243, 0.3);
}

.recording-wave {
  width: 50px; 
  height: 50px; 
  background: #FFFFFF; 
  border-radius: 50%; 
  margin: 0 auto;
  animation: pulse 1s infinite cubic-bezier(0.4, 0, 0.6, 1);
  opacity: 0.9;
}

@keyframes pulse {
  0% { transform: scale(0.9); box-shadow: 0 0 0 0 rgba(255, 255, 255, 0.7); }
  70% { transform: scale(1.1); box-shadow: 0 0 0 15px rgba(33, 150, 243, 0); }
  100% { transform: scale(0.9); box-shadow: 0 0 0 0 rgba(33, 150, 243, 0); }
}

/* 响应式设计 */
@media screen and (max-width: 1024px) {
  .input-area { padding: 14px; }
  .glass-tag { font-size: 12px; }
}

@media screen and (max-width: 768px) {
  .input-area { padding: 12px; }
  .quick-actions { gap: 8px; }
  .glass-tag { font-size: 11px; padding: 4px 8px; }
}

@media screen and (max-width: 480px) {
  .input-area {
    padding: 8px 10px;
    position: relative;
    z-index: 100;
    background: linear-gradient(180deg, rgba(245, 247, 250, 0.95) 0%, rgba(240, 245, 255, 0.95) 100%);
  }

  .quick-actions {
    gap: 4px;
    flex-direction: row;
    justify-content: space-between;
    margin-bottom: 6px;
  }

  .preset-questions {
    gap: 4px;
    margin-bottom: 6px;
    display: grid;
    grid-template-columns: 1fr 1fr;
  }

  .glass-tag {
    font-size: 11px;
    padding: 4px 8px;
    white-space: nowrap;
  }

  .glass-input :deep(.el-input__wrapper) {
    border-radius: 16px;
    padding: 2px 12px;
    height: 32px;
    font-size: 13px;
  }

  .send-btn {
    height: 32px;
    min-width: 32px;
    padding: 0 8px;
  }

  .mic-icon {
    font-size: 18px;
    padding: 2px;
  }
}
</style>
