<template>
  <div class="pdf-viewer-area">
    <!-- 流式工具栏（与教师端一致） -->
    <div class="stage-toolbar glass-toolbar" v-if="source">
      <!-- 缩放控件 -->
      <div class="zoom-controls">
        <el-button-group>
          <el-button size="small" :icon="ZoomOut" @click="handleZoom(-0.1)" />
          <el-button size="small" class="zoom-text">{{ Math.round(scale * 100) }}%</el-button>
          <el-button size="small" :icon="ZoomIn" @click="handleZoom(0.1)" />
        </el-button-group>
      </div>
      <!-- 翻页导航 -->
      <div class="pdf-navigation" v-if="totalPages > 0">
        <el-button size="small" :disabled="page <= 1" @click="$emit('changePage', -1)">← 上一页</el-button>
        <span class="page-info">{{ page }} / {{ totalPages }}</span>
        <el-input-number 
          v-model="jumpPage" 
          :min="1" 
          :max="totalPages" 
          :controls="false"
          size="small"
          class="page-jump-input"
          @keyup.enter="handleJumpPage"
          placeholder="跳转"
        />
        <el-button size="small" type="primary" @click="handleJumpPage">跳转</el-button>
        <el-button size="small" :disabled="page >= totalPages" @click="$emit('changePage', 1)">下一页 →</el-button>
      </div>
    </div>

    <!-- 内容区 -->
    <div class="pdf-wrapper" ref="pdfViewRef" @mouseup="handleTextSelection">
      <!-- PPTX 直预览 -->
      <template v-if="isPptxFile && source">
        <div ref="pptxContainer" class="pptx-preview-container"></div>
      </template>

      <!-- PPT 文件预览 -->
      <template v-else-if="isPptFile && source">
        <template v-if="canUseOfficePreview">
          <iframe
            :src="getPptPreviewUrl()"
            class="ppt-iframe"
            frameborder="0"
            allowfullscreen
            title="PPT 预览"
          ></iframe>
        </template>
        <!-- 本地 .ppt 文件：后端正在转换为 PDF，请等待轮询自动刷新 -->
        <div v-else class="empty-state">
          <el-empty image-size="90">
            <template #description>
              <p style="color:#88909b;font-size:14px;">PPT 正在转换为可预览格式，请稍候…</p>
              <p style="color:#b0b4bc;font-size:12px;margin-top:4px;">转换完成后将自动显示</p>
            </template>
            <el-button type="primary" plain @click="openInNewTab">先下载原文件查看</el-button>
          </el-empty>
        </div>
      </template>

      <!-- PDF 单页预览（与教师端一致） -->
      <template v-else-if="source">
        <!-- 隐藏实例：仅用于获取总页数和宽高比 -->
        <div style="display:none">
          <VuePdfEmbed :key="source" :source="source" @loaded="onLoaded" />
        </div>
        <!-- 可见实例：横向幻灯片居中，纵向文档顶部对齐 -->
        <div :class="['pdf-center-wrapper', isLandscapePdf ? 'landscape-mode' : 'portrait-mode']" v-if="totalPages > 0">
          <div class="pdf-page-wrapper glass-page-shadow" :style="{ transform: `scale(${scale})`, transformOrigin: 'center center' }">
            <VuePdfEmbed
              :key="source + '-p' + page"
              :source="source"
              :page="page"
              :width="pdfRenderWidth"
              :text-layer="true"
              :annotation-layer="true"
              class="pdf-content"
              @rendered="onPageRendered"
            />
            <!-- 公式交互层 -->
            <div class="formula-overlay-layer">
              <div
                v-for="(region, index) in formulaRegions"
                :key="index"
                class="formula-region"
                :class="{ 'hovered': hoveredFormulaIndex === index }"
                :style="{
                  left: region.left + 'px',
                  top: region.top + 'px',
                  width: region.width + 'px',
                  height: region.height + 'px'
                }"
                @mouseenter="hoveredFormulaIndex = index"
                @mouseleave="hoveredFormulaIndex = -1"
                @click="handleFormulaClick(region)"
              >
                <div class="formula-tooltip" v-if="hoveredFormulaIndex === index">
                  点击提问此公式
                </div>
              </div>
            </div>
          </div>
        </div>
      </template>

      <!-- 空状态 -->
      <div v-else class="empty-state">
        <el-empty description="暂无课件，请点击右上角导入" image-size="100">
          <el-button type="primary" plain @click="$emit('upload')">上传 PDF</el-button>
        </el-empty>
      </div>

      <!-- 加载遮罩 -->
      <div v-if="loading" class="upload-mask glass-mask">
        <div class="loading-box">
          <el-icon class="is-loading" :size="40" color="#0077ff"><Loading /></el-icon>
          <p style="color:#5c626e">AI 正在解析文档结构...</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch, nextTick, onMounted, onUnmounted } from 'vue'
import VuePdfEmbed from 'vue-pdf-embed'
import 'vue-pdf-embed/dist/styles/annotationLayer.css'
import 'vue-pdf-embed/dist/styles/textLayer.css'
import { init as initPptxPreview } from 'pptx-preview'
import { ZoomIn, ZoomOut, Loading } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'

const props = defineProps(['source', 'page', 'loading'])
const emit = defineEmits(['changePage', 'upload', 'textSelected', 'formulaSelected'])

const scale = ref(1.0)
const totalPages = ref(0)
const jumpPage = ref(null)  // 新增：跳转页码
const pptxContainer = ref(null)
const pdfViewRef = ref(null)
const pdfRenderWidth = ref(800)
const pdfAspectRatio = ref(null) // null = 未知; ≥1 = 横向(幻灯片); <1 = 纵向(文档)
let pptxPreviewer = null
let resizeTimer = null
let measureRetryTimer = null
let containerObserver = null

// 新增：公式检测相关
const formulaRegions = ref([])
const hoveredFormulaIndex = ref(-1)

// 横向（幻灯片类 PDF）：居中 + 适配页面；纵向（文字类 PDF）：顶部对齐 + 适配宽度
const isLandscapePdf = computed(() => pdfAspectRatio.value !== null && pdfAspectRatio.value >= 1)
// ---------- 文件类型判断 ----------
const isPptFile = computed(() => {
  if (!props.source) return false
  const s = String(props.source).toLowerCase()
  return s.endsWith('.ppt') || s.endsWith('.pptx')
})
const isPptxFile = computed(() => {
  if (!props.source) return false
  return String(props.source).toLowerCase().endsWith('.pptx')
})
const isPdfFile = computed(() => {
  if (!props.source) return false
  return String(props.source).toLowerCase().endsWith('.pdf')
})

// ---------- PPT 在线预览 ----------
const getPptPreviewUrl = () => {
  if (!props.source) return ''
  let fullUrl = props.source
  if (fullUrl.startsWith('/')) fullUrl = `http://localhost:8989${fullUrl}`
  return `https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(fullUrl)}`
}
const canUseOfficePreview = computed(() => {
  if (!props.source || !isPptFile.value || isPptxFile.value) return false
  if (props.source.startsWith('/')) return false
  try {
    const host = new URL(String(props.source)).hostname.toLowerCase()
    return !['localhost', '127.0.0.1'].includes(host) && !host.startsWith('192.168.') && !host.startsWith('10.') && !host.startsWith('172.')
  } catch { return false }
})
const openInNewTab = () => { if (props.source) window.open(props.source, '_blank') }

// ---------- PDF 自适应宽度 ----------
// 横向（幻灯片类）：取宽/高两个维度的较小值，确保完整显示 → 居中对齐
// 纵向（文字类）  ：只约束宽度，允许纵向滚动读文档               → 顶部对齐
const recalcPdfWidth = () => {
  if (!pdfViewRef.value) return
  const rect = pdfViewRef.value.getBoundingClientRect()
  if (rect.width < 10) return
  const pad = 24
  const aspect = pdfAspectRatio.value
  if (aspect !== null && aspect >= 1) {
    // 横向（PPT 幻灯片）：同时适配宽度和高度，保证四周均等留白
    const maxByWidth = Math.floor(rect.width - pad)
    const maxByHeight = Math.floor((rect.height - pad) * aspect)
    pdfRenderWidth.value = Math.max(Math.min(maxByWidth, maxByHeight), 300)
  } else {
    // 纵向（文字 PDF）：铺满宽度，纵向可滚动
    pdfRenderWidth.value = Math.floor(rect.width - pad)
  }
}

const onLoaded = async (doc) => {
  totalPages.value = doc.numPages
  try {
    const p = await doc.getPage(1)
    const vp = p.getViewport({ scale: 1 })
    pdfAspectRatio.value = vp.width / vp.height // 横向 ≥1，纵向 <1
    recalcPdfWidth()
  } catch {
    recalcPdfWidth()
  }
}

// ---------- PPTX 预览 ----------
const renderPptxPreview = async () => {
  if (!isPptxFile.value || !props.source || !pptxContainer.value) return
  try {
    const rect = pptxContainer.value.getBoundingClientRect()
    if (rect.width < 300 || rect.height < 240) {
      if (measureRetryTimer) clearTimeout(measureRetryTimer)
      measureRetryTimer = setTimeout(() => renderPptxPreview(), 220)
      return
    }
    pptxContainer.value.innerHTML = ''
    const containerWidth = Math.max(560, Math.floor(rect.width - 8))
    const maxHeight = Math.max(360, Math.floor(rect.height - 8))
    const fitHeight = Math.min(maxHeight, Math.floor((containerWidth * 9) / 16))
    pptxPreviewer = initPptxPreview(pptxContainer.value, { width: containerWidth, height: fitHeight, mode: 'list' })
    const resp = await fetch(props.source)
    const buf = await resp.arrayBuffer()
    await pptxPreviewer.preview(buf)
  } catch (e) {
    console.error('[PPTX预览] 失败:', e)
    ElMessage.warning('PPTX 直预览失败，请稍后重试')
  }
}

const handleWindowResize = () => {
  if (resizeTimer) clearTimeout(resizeTimer)
  resizeTimer = setTimeout(() => {
    if (isPptxFile.value) renderPptxPreview()
    else if (isPdfFile.value) recalcPdfWidth() // 已有 pdfAspectRatio，自动选取正确策略
  }, 180)
}

const handleZoom = (delta) => {
  const v = scale.value + delta
  if (v >= 0.5 && v <= 3.0) scale.value = Number(v.toFixed(1))
}

// 新增：页码跳转
const handleJumpPage = () => {
  if (!jumpPage.value || jumpPage.value < 1 || jumpPage.value > totalPages.value) {
    ElMessage.warning('请输入有效的页码')
    return
  }
  const targetPage = Number(jumpPage.value)
  const delta = targetPage - props.page
  emit('changePage', delta)
  jumpPage.value = null  // 清空输入框
}

// 新增：处理文本选择
const handleTextSelection = () => {
  const selection = window.getSelection()
  const selectedText = selection?.toString().trim()
  
  if (selectedText && selectedText.length > 3) {
    // 延迟一下，让用户看到选中效果
    setTimeout(() => {
      emit('textSelected', {
        text: selectedText,
        page: props.page
      })
      // 清除选中状态
      selection.removeAllRanges()
    }, 300)
  }
}

// 新增：PDF页面渲染完成后检测公式
const onPageRendered = async () => {
  console.log('[PDF渲染] 页面渲染完成，开始检测公式')
  // 等待文本层渲染完成
  await nextTick()
  setTimeout(() => {
    detectFormulas()
  }, 500) // 延迟500ms确保文本层完全渲染
}

// 新增：检测页面中的公式区域
const detectFormulas = () => {
  formulaRegions.value = []
  
  if (!pdfViewRef.value) {
    console.log('[公式检测] pdfViewRef 不存在')
    return
  }
  
  // 查找文本层中的所有文本元素
  const textLayer = pdfViewRef.value.querySelector('.textLayer')
  if (!textLayer) {
    console.log('[公式检测] 未找到 textLayer')
    return
  }
  
  const textSpans = textLayer.querySelectorAll('span')
  console.log('[公式检测] 找到', textSpans.length, '个文本元素')
  
  // 扩展的公式特征检测
  const mathSymbols = /[∫∑∏√∂∇±×÷≈≠≤≥∞αβγδεθλμπσφψω]/
  const greekLetters = /[αβγδεζηθικλμνξοπρστυφχψω]/
  const operators = /[∫∑∏√∂∇]/
  
  // 新增：检测常见的数学表达式模式
  const mathPatterns = [
    /[A-Z][a-z]?\s*[=≈]\s*/, // 如 "σ = ", "M = "
    /\s*[=≈]\s*[A-Z]/, // 如 "= M"
    /\d+\s*[×÷]\s*\d+/, // 数字运算
    /[A-Z]_[a-z]/, // 下标，如 M_z
    /[A-Z]\^[0-9]/, // 上标，如 x^2
    /\([A-Za-z0-9\s+\-*/]+\)/, // 括号表达式
    /\b(sin|cos|tan|log|ln|exp|sqrt)\b/i, // 数学函数
    /\d+\s*\/\s*\d+/, // 分数
    /[EI][A-Z]_[a-z]/ // 如 EI_z
  ]
  
  // 获取PDF页面容器的位置
  const pdfContent = pdfViewRef.value.querySelector('.pdf-content')
  if (!pdfContent) {
    console.log('[公式检测] 未找到 pdf-content')
    return
  }
  
  const containerRect = pdfContent.getBoundingClientRect()
  
  textSpans.forEach((span, index) => {
    const text = span.textContent || ''
    
    // 打印前10个元素的内容用于调试
    if (index < 10) {
      console.log(`[公式检测] 元素${index}: "${text}"`)
    }
    
    // 检测是否包含数学符号或匹配数学模式
    const hasSymbol = mathSymbols.test(text) || greekLetters.test(text) || operators.test(text)
    const matchesPattern = mathPatterns.some(pattern => pattern.test(text))
    
    if (hasSymbol || matchesPattern) {
      const rect = span.getBoundingClientRect()
      
      // 计算相对于PDF内容的位置
      const region = {
        text: text,
        left: rect.left - containerRect.left,
        top: rect.top - containerRect.top,
        width: Math.max(rect.width, 30), // 最小宽度30px
        height: Math.max(rect.height, 20) // 最小高度20px
      }
      
      formulaRegions.value.push(region)
      console.log('[公式检测] 检测到公式:', text, region)
    }
  })
  
  console.log(`[公式检测] 总共检测到 ${formulaRegions.value.length} 个公式区域`)
}

// 新增：处理公式点击
const handleFormulaClick = (region) => {
  console.log('[公式点击]', region.text)
  
  emit('textSelected', {
    text: region.text,
    page: props.page,
    isFormula: true
  })
  
  ElMessage.success('已选中公式')
}

watch(() => props.source, async () => {
  totalPages.value = 0
  scale.value = 1.0
  pdfAspectRatio.value = null
  formulaRegions.value = [] // 清空公式区域
  await nextTick()
  if (isPptxFile.value) {
    await renderPptxPreview()
  } else if (isPdfFile.value) {
    recalcPdfWidth()
  }
}, { immediate: true })

// 监听页码变化，重新检测公式
watch(() => props.page, async () => {
  formulaRegions.value = [] // 清空公式区域
  hoveredFormulaIndex.value = -1
  console.log('[页码变化] 清空公式区域，等待新页面渲染')
})

onMounted(() => {
  window.addEventListener('resize', handleWindowResize)
  recalcPdfWidth()
  containerObserver = new ResizeObserver(() => handleWindowResize())
  if (pptxContainer.value) containerObserver.observe(pptxContainer.value)
  if (pdfViewRef.value) containerObserver.observe(pdfViewRef.value)
})
onUnmounted(() => {
  if (resizeTimer) clearTimeout(resizeTimer)
  if (measureRetryTimer) clearTimeout(measureRetryTimer)
  if (containerObserver) containerObserver.disconnect()
  window.removeEventListener('resize', handleWindowResize)
})
</script>

<style scoped>
/* 1. 外层容器：浅蓝色企业风格背景 */
.pdf-viewer-area {
  flex: 1;
  display: flex;
  flex-direction: column;
  background: linear-gradient(180deg, #F5F7FA 0%, #F0F5FF 100%);
  overflow: hidden;
}

/* 2. 顶部流式工具栏：清爽企业风格 */
.stage-toolbar {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 8px 16px;
  flex-shrink: 0;
  min-height: 48px;
  background: linear-gradient(90deg, #FFFFFF 0%, #F8FBFE 100%);
  border-bottom: 1px solid rgba(33, 150, 243, 0.15);
  box-shadow: 0 2px 6px rgba(33, 150, 243, 0.08);
}
.glass-toolbar {
  background: linear-gradient(90deg, #FFFFFF 0%, #F8FBFE 100%);
  backdrop-filter: blur(2px);
  border-bottom: 1px solid rgba(33, 150, 243, 0.15);
}

.zoom-controls {
  background: #FFFFFF;
  padding: 4px 8px;
  border-radius: 6px;
  box-shadow: 0 2px 4px rgba(33, 150, 243, 0.08);
  display: flex;
  align-items: center;
  border: 1px solid rgba(33, 150, 243, 0.15);
  transition: all 0.3s;
}

.zoom-controls:hover {
  box-shadow: 0 4px 8px rgba(33, 150, 243, 0.12);
}

.zoom-text { 
  min-width: 40px; 
  text-align: center; 
  color: #1976D2; 
  font-weight: 600; 
  font-size: 13px; 
}

.pdf-navigation {
  background: #FFFFFF;
  padding: 4px 12px;
  border-radius: 6px;
  box-shadow: 0 2px 4px rgba(33, 150, 243, 0.08);
  display: flex;
  align-items: center;
  gap: 8px;
  border: 1px solid rgba(33, 150, 243, 0.15);
  transition: all 0.3s;
  flex: 1;
  justify-content: center;
}

.pdf-navigation:hover {
  box-shadow: 0 4px 8px rgba(33, 150, 243, 0.12);
}

.page-info { 
  font-size: 13px; 
  color: #1976D2; 
  font-weight: 600; 
  white-space: nowrap; 
}
.page-jump-input { width: 80px; }
.page-jump-input :deep(.el-input__inner) { text-align: center; }

/* 内容容器 */
.pdf-wrapper {
  flex: 1;
  position: relative;
  overflow: hidden;
  width: 100%;
}

/* 3. PDF 预览容器基础样式：浅蓝色背景 */
.pdf-center-wrapper {
  position: absolute;
  inset: 0;
  display: flex;
  justify-content: center;
  padding: 12px;
  background: linear-gradient(180deg, #F5F7FA 0%, #F0F5FF 100%);
}
/* 横向（幻灯片类 PDF）：居中对齐，四周留白均等 */
.pdf-center-wrapper.landscape-mode {
  align-items: center;
  overflow: auto;
}
/* 纵向（文字类 PDF）：顶部对齐，允许纵向滚动 */
.pdf-center-wrapper.portrait-mode {
  align-items: flex-start;
  overflow-y: auto;
  overflow-x: hidden;
}

/* 4. PDF页面本身纸张效果：保持白色以保证阅读，但加上柔和投影悬浮感 */
.pdf-page-wrapper {
  width: 100%;
  position: relative;
  background: #ffffff;
}
.glass-page-shadow {
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
  border-radius: 2px;
}

/* 【新增】公式交互层 */
.formula-overlay-layer {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  z-index: 20;
}

.formula-region {
  position: absolute;
  pointer-events: auto;
  cursor: pointer;
  transition: all 0.2s ease;
  border-radius: 4px;
  border: 2px solid transparent;
}

.formula-region:hover {
  background: rgba(0, 119, 255, 0.15);
  border-color: rgba(0, 119, 255, 0.5);
  box-shadow: 0 0 8px rgba(0, 119, 255, 0.2);
  z-index: 21;
}

.formula-region.hovered {
  background: rgba(0, 119, 255, 0.2);
  border-color: rgba(0, 119, 255, 0.7);
}

.formula-tooltip {
  position: absolute;
  bottom: calc(100% + 8px);
  left: 50%;
  transform: translateX(-50%);
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(4px);
  color: #0077ff;
  border: 1px solid #c6e2ff;
  padding: 8px 14px;
  border-radius: 6px;
  font-size: 13px;
  white-space: nowrap;
  pointer-events: none;
  z-index: 100;
  box-shadow: 0 4px 12px rgba(0, 119, 255, 0.1);
  animation: fadeIn 0.2s ease;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateX(-50%) translateY(5px);
  }
  to {
    opacity: 1;
    transform: translateX(-50%) translateY(0);
  }
}

.formula-tooltip::after {
  content: '';
  position: absolute;
  top: 100%;
  left: 50%;
  transform: translateX(-50%);
  border: 6px solid transparent;
  border-top-color: rgba(255, 255, 255, 0.9);
}

/* 【新增】启用PDF文本选择 */
.pdf-content {
  user-select: text;
  -webkit-user-select: text;
  -moz-user-select: text;
  -ms-user-select: text;
}

/* 【新增】PDF文本层样式 */
.pdf-content :deep(.textLayer) {
  position: absolute;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  overflow: hidden;
  opacity: 1;
  line-height: 1;
  user-select: text;
  -webkit-user-select: text;
}

.pdf-content :deep(.textLayer span) {
  color: transparent;
  position: absolute;
  white-space: pre;
  cursor: text;
  transform-origin: 0% 0%;
}

.pdf-content :deep(.textLayer ::selection) {
  background: rgba(0, 119, 255, 0.2); /* 降低选区颜色的突兀感 */
}

.pdf-content :deep(.textLayer ::-moz-selection) {
  background: rgba(0, 119, 255, 0.2);
}

/* 5. PPTX 预览区：透明背景 */
.pptx-preview-container {
  position: absolute;
  inset: 0;
  overflow: auto;
  background: transparent;
}

/* PPT iframe */
.ppt-iframe {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  border-radius: 0;
}

/* 空状态：透明背景 */
.empty-state {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: transparent;
}

/* 6. 加载遮罩：浅色透玻璃，保持整体风格一致 */
.upload-mask {
  position: absolute;
  inset: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 20;
}
.glass-mask {
  background: rgba(255, 255, 255, 0.85);
  backdrop-filter: blur(4px);
}
.loading-box { text-align: center; }
.loading-box p { margin-top: 12px; font-size: 14px; font-weight: 500; color: #5C626E; }

/* 美化滚动条 */
.pdf-center-wrapper::-webkit-scrollbar,
.pptx-preview-container::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}
.pdf-center-wrapper::-webkit-scrollbar-thumb,
.pptx-preview-container::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 10px;
}
.pdf-center-wrapper::-webkit-scrollbar-track,
.pptx-preview-container::-webkit-scrollbar-track {
  background: transparent;
}

/* 响应式设计 - 平板 */
@media (max-width: 1024px) {
  .stage-toolbar {
    padding: 8px 12px;
    gap: 8px;
    flex-wrap: wrap;
  }
  .zoom-controls, .pdf-navigation {
    padding: 3px 6px;
    gap: 6px;
  }
  .page-info { font-size: 12px; }
  .zoom-text { min-width: 35px; }
}

/* 响应式设计 - 平板竖屏 */
@media (max-width: 768px) {
  .pdf-viewer-area {
    background: #F5F7FA;
  }
  .stage-toolbar {
    padding: 6px 10px;
    gap: 6px;
    height: auto;
    min-height: 44px;
  }
  .zoom-controls, .pdf-navigation {
    padding: 2px 5px;
    gap: 4px;
    font-size: 12px;
  }
  .page-info { font-size: 11px; }
  .zoom-text { min-width: 30px; font-size: 12px; }
  .pdf-center-wrapper {
    padding: 8px;
  }
}

/* 响应式设计 - 手机 */
@media (max-width: 480px) {
  .stage-toolbar {
    padding: 4px 8px;
    gap: 4px;
    min-height: 40px;
  }
  .zoom-controls, .pdf-navigation {
    padding: 1px 4px;
    gap: 2px;
    font-size: 11px;
  }
  .page-info { font-size: 10px; }
  .zoom-text { min-width: 25px; font-size: 11px; }
  .pdf-center-wrapper {
    padding: 4px;
  }
  .pdf-page-wrapper {
    border-radius: 1px;
  }
}
</style>
