<template>
  <div class="ai-sidebar" :style="{ width: width + 'px' }">
    <!-- 顶部标签栏 -->
    <div class="sidebar-tabs">
      <div class="tab-item" :class="{ active: activeTab === 'lecture' }" @click="activeTab = 'lecture'">
        <el-icon><Headset /></el-icon> 伴随讲解
      </div>
      <div class="tab-item" :class="{ active: activeTab === 'chat' }" @click="activeTab = 'chat'">
        <el-icon><ChatDotRound /></el-icon> 互动答疑
      </div>
      <div class="tab-item" :class="{ active: activeTab === 'mindmap' }" @click="activeTab = 'mindmap'">
        <el-icon><Share /></el-icon> 思维导图
      </div>
      <div class="tab-item" :class="{ active: activeTab === 'knowledge' }" @click="activeTab = 'knowledge'">
        <el-icon><Connection /></el-icon> 知识图谱
      </div>
    </div>
    
    <!-- 伴随讲解和互动答疑标签页 -->
    <template v-if="activeTab === 'lecture' || activeTab === 'chat'">
      <ChatArea 
        :mode="mode" 
        :script="script" 
        :audioUrl="audioUrl"
        :history="history" 
        :isChatLoading="isChatLoading" 
        @speakContent="(content) => $emit('speakContent', content)"
        @resolve="(idx) => $emit('resolve', idx)"
        @jumpToPage="(page) => $emit('jumpToPage', page)"
        @chatTextSelected="(data) => $emit('chatTextSelected', data)"
      />
      <InputBox 
        v-model="inputVal" 
        :mode="mode" 
        :placeholder="placeholder"
        @send="onSend"
        @replay="$emit('replay')"
        @switchToChat="activeTab = 'chat'; handleTabChange('chat')"
        @resolve="(idx) => $emit('resolve', idx)" 
      />
    </template>
    
    <!-- 思维导图标签页 -->
    <div v-else-if="activeTab === 'mindmap'" class="mindmap-container">
      <div class="mindmap-content">
        <div v-if="!mindmapData" class="mindmap-placeholder">
          <el-icon class="mindmap-icon" size="48"><Share /></el-icon>
          <h3>思维导图</h3>
          <p>基于当前课件内容生成的结构化思维导图</p>
          <el-button type="primary" size="small" @click="generateMindmap" :loading="isGeneratingMindmap">生成思维导图</el-button>
        </div>
        <div v-else class="mindmap-visualization">
          <div class="mindmap-loading" v-if="isGeneratingMindmap">
            <el-icon class="is-loading"><Loading /></el-icon>
            <span>正在生成思维导图...</span>
          </div>
          <div v-else class="mindmap-canvas">
            <svg class="mindmap-svg" viewBox="0 0 800 500" @wheel="handleSvgWheel">
              <g class="mindmap-lines">
                <path v-for="(branch, index) in mindmapData.branches" 
                      :key="'line-'+index"
                      :d="getBranchLinePath(branch, index)"
                      :stroke="branch.color"
                      stroke-width="2"
                      fill="none"
                      class="mindmap-line"
                />
                <path v-for="(line, index) in subLines" 
                      :key="'subline-'+index"
                      :d="line.path"
                      :stroke="line.color"
                      stroke-width="1.5"
                      fill="none"
                      class="mindmap-line"
                />
              </g>
              <g class="mindmap-center">
                <rect x="320" y="210" width="160" height="80" rx="40" fill="#409eff" class="mindmap-center-node"/>
                <text x="400" y="255" text-anchor="middle" fill="white" font-size="16" font-weight="500">{{ mindmapData.center }}</text>
              </g>
              <g v-for="(branch, index) in mindmapData.branches" :key="'branch-'+index" class="mindmap-branch">
                <rect :x="branch.x" :y="branch.y" width="100" height="40" rx="20" 
                      :fill="branch.color" fill-opacity="0.1" :stroke="branch.color" stroke-width="2" class="mindmap-branch-node"/>
                <text :x="branch.x + 50" :y="branch.y + 26" text-anchor="middle" :fill="branch.color" font-size="14" font-weight="500">{{ branch.label }}</text>
                <g v-for="(sub, subIndex) in branch.children" :key="'sub-'+index+'-'+subIndex" class="mindmap-sub">
                  <circle :cx="sub.x" :cy="sub.y" r="4" :fill="branch.color"/>
                  <text :x="sub.x + (sub.x > branch.x ? 10 : -10)" :y="sub.y + 5" 
                        :text-anchor="sub.x > branch.x ? 'start' : 'end'" 
                        fill="#666" font-size="12">{{ sub.label }}</text>
                </g>
              </g>
            </svg>
          </div>
        </div>
      </div>
    </div>
    
    <!-- 知识图谱标签页 -->
    <div v-else-if="activeTab === 'knowledge'" class="knowledge-graph-container">
      <div class="knowledge-graph-content">
        <div v-if="!knowledgeGraphData" class="knowledge-graph-placeholder">
          <el-icon class="knowledge-graph-icon" size="48"><Connection /></el-icon>
          <h3>知识图谱</h3>
          <p>基于当前课件内容生成的知识关联网络</p>
          <el-button type="primary" size="small" @click="generateKnowledgeGraph" :loading="isGeneratingGraph">生成知识图谱</el-button>
        </div>
        <div v-else class="knowledge-graph-visualization">
          <div class="knowledge-graph-loading" v-if="isGeneratingGraph">
            <el-icon class="is-loading"><Loading /></el-icon>
            <span>正在生成知识图谱...</span>
          </div>
          <div v-else class="knowledge-graph-canvas">
            <svg class="knowledge-graph-svg" viewBox="0 0 800 500" @wheel="handleSvgWheel">
              <g class="knowledge-graph-lines">
                <line v-for="(edge, index) in knowledgeGraphData.edges" 
                      :key="'edge-'+index"
                      :x1="getNodePosition(edge.source).x"
                      :y1="getNodePosition(edge.source).y"
                      :x2="getNodePosition(edge.target).x"
                      :y2="getNodePosition(edge.target).y"
                      stroke="#ccc"
                      stroke-width="1.5"
                      class="knowledge-graph-line"
                />
              </g>
              <g v-for="node in knowledgeGraphData.nodes" :key="'node-'+node.id" class="knowledge-graph-node">
                <circle :cx="node.x" :cy="node.y" :r="node.size" :fill="node.color" fill-opacity="0.8"/>
                <text :x="node.x" :y="node.y + 5" text-anchor="middle" fill="white" font-size="12" font-weight="500">{{ node.label }}</text>
              </g>
            </svg>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import { Headset, ChatDotRound, Share, Connection, Loading } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import ChatArea from './ChatArea.vue'
import InputBox from './InputBox.vue'
import { getMindmap, getKnowledgeGraph } from '@/api/lesson'

const props = defineProps({
  width: { type: Number, default: 350 },
  mode: { type: String, default: 'lecture' },
  script: { type: String, default: '' },
  audioUrl: { type: String, default: '' },
  history: { type: Array, default: () => [] },
  placeholder: { type: String, default: '输入您的问题...' },
  isChatLoading: { type: Boolean, default: false },
  courseId: { type: [String, Number], default: '' }
})

const emit = defineEmits(['update:mode', 'replay', 'sendMessage', 'resolve', 'speakContent', 'jumpToPage', 'chatTextSelected'])
const inputVal = ref('')
const activeTab = ref('lecture')

const handleTabChange = (tab) => {
  if (tab === 'lecture' || tab === 'chat') {
    emit('update:mode', tab)
  }
}

watch(() => activeTab.value, (newTab) => {
  handleTabChange(newTab)
})

const mindmapData = ref(null)
const isGeneratingMindmap = ref(false)
const knowledgeGraphData = ref(null)
const isGeneratingGraph = ref(false)

const mode = computed(() => props.mode)

const subLines = computed(() => {
  if (!mindmapData.value) return []
  const lines = []
  mindmapData.value.branches.forEach(branch => {
    if (branch.children) {
      branch.children.forEach(child => {
        lines.push({
          path: `M ${branch.x + (branch.x > 400 ? 100 : 0)} ${branch.y + 20} L ${child.x} ${child.y}`,
          color: branch.color
        })
      })
    }
  })
  return lines
})

const getBranchLinePath = (branch, index) => {
  const startX = 400
  const startY = 250
  const endX = branch.x + 50
  const endY = branch.y + 20
  return `M ${startX} ${startY} L ${endX} ${endY}`
}

const getNodePosition = (nodeId) => {
  if (!knowledgeGraphData.value) return { x: 0, y: 0 }
  const node = knowledgeGraphData.value.nodes.find(n => n.id === nodeId)
  return node ? { x: node.x, y: node.y } : { x: 0, y: 0 }
}

const convertMindmapData = (backendData) => {
  if (!backendData || !backendData.root) return null
  const root = backendData.root
  const colors = ['#409eff', '#67c23a', '#e6a23c', '#f56c6c', '#909399', '#8B5CF6']
  
  const branches = root.children ? root.children.map((child, index) => {
    const angle = (index / root.children.length) * 2 * Math.PI
    const radius = 200
    const x = 400 + radius * Math.cos(angle) - 50
    const y = 250 + radius * Math.sin(angle) * 0.6 - 20
    
    const children = child.children ? child.children.map((sub, subIndex) => {
      const subAngle = angle + (subIndex - child.children.length / 2) * 0.3
      const subRadius = 320
      return {
        x: 400 + subRadius * Math.cos(subAngle),
        y: 250 + subRadius * Math.sin(subAngle) * 0.6,
        label: sub.text || sub.label || '子项'
      }
    }) : []
    
    return {
      x: x,
      y: y,
      label: child.text || child.label || '分支',
      color: colors[index % colors.length],
      children: children
    }
  }) : []
  
  return {
    center: root.text || root.label || '课件主题',
    branches: branches
  }
}

const nodeColors = {
  'concept': '#409eff',
  'keyword': '#67c23a',
  'principle': '#e6a23c',
  'example': '#f56c6c',
  'default': '#909399'
}

const convertKnowledgeGraphData = (backendData) => {
  if (!backendData || !backendData.nodes) return null
  
  const nodes = backendData.nodes.map((node, index) => {
    const angle = (index / backendData.nodes.length) * 2 * Math.PI
    const radius = node.type === 'concept' ? 0 : 180
    const x = 400 + radius * Math.cos(angle)
    const y = 250 + radius * Math.sin(angle)
    
    return {
      id: node.id,
      label: node.name || node.label || '未命名',
      x: x,
      y: y,
      size: node.type === 'concept' ? 40 : (node.type === 'principle' ? 30 : 25),
      color: nodeColors[node.type] || nodeColors.default
    }
  })
  
  const edges = backendData.edges ? backendData.edges.map(edge => ({
    source: edge.source,
    target: edge.target
  })) : []
  
  return { nodes, edges }
}

const generateMindmap = async () => {
  if (!props.courseId) {
    ElMessage.warning('请先选择课程')
    return
  }
  isGeneratingMindmap.value = true
  try {
    const res = await getMindmap(props.courseId)
    if (res.data) {
      mindmapData.value = convertMindmapData(res.data)
      ElMessage.success('思维导图生成成功')
    } else {
      ElMessage.warning('暂无思维导图数据')
    }
  } catch (e) {
    console.error('生成思维导图失败:', e)
    ElMessage.error('生成思维导图失败')
  } finally {
    isGeneratingMindmap.value = false
  }
}

const generateKnowledgeGraph = async () => {
  if (!props.courseId) {
    ElMessage.warning('请先选择课程')
    return
  }
  isGeneratingGraph.value = true
  try {
    const res = await getKnowledgeGraph(props.courseId)
    if (res.data) {
      knowledgeGraphData.value = convertKnowledgeGraphData(res.data)
      ElMessage.success('知识图谱生成成功')
    } else {
      ElMessage.warning('暂无知识图谱数据')
    }
  } catch (e) {
    console.error('生成知识图谱失败:', e)
    ElMessage.error('生成知识图谱失败')
  } finally {
    isGeneratingGraph.value = false
  }
}

const onSend = () => {
  if (inputVal.value.trim()) {
    emit('sendMessage', inputVal.value)
    inputVal.value = ''
  }
}

// SVG 缩放功能
let svgScale = 1
const handleSvgWheel = (e) => {
  if (e.ctrlKey || e.metaKey) {
    e.preventDefault()
    const svg = e.target.closest('svg')
    if (svg) {
      svgScale += e.deltaY > 0 ? -0.1 : 0.1
      svgScale = Math.max(0.5, Math.min(svgScale, 3))
      svg.style.transform = `scale(${svgScale})`
      svg.style.transformOrigin = 'center'
    }
  }
}

// 重置思维导图和知识图谱数据
const resetGraphData = () => {
  mindmapData.value = null
  knowledgeGraphData.value = null
  svgScale = 1
}

defineExpose({ resetGraphData })
</script>

<style scoped>
.ai-sidebar {
  min-width: 300px;
  max-width: 800px;
  background: #FFFFFF;
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  overflow: hidden;
  border-left: 1px solid rgba(33, 150, 243, 0.15);
  box-shadow: -2px 0 12px rgba(33, 150, 243, 0.08);
  margin: 0;
}

.sidebar-tabs {
  display: flex;
  background: #FFFFFF;
  border-bottom: 1px solid rgba(33, 150, 243, 0.15);
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
  scrollbar-width: none;
}

.sidebar-tabs::-webkit-scrollbar {
  display: none;
}

.tab-item {
  flex: 1;
  text-align: center;
  padding: 14px 12px;
  cursor: pointer;
  font-size: 14px;
  color: #2196F3;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  transition: all 0.3s ease;
  position: relative;
  font-weight: 500;
  white-space: nowrap;
  min-width: 0;
  outline: none;
  border: none;
}

.tab-item:focus {
  outline: none;
}

.tab-item:hover {
  background: rgba(33, 150, 243, 0.08);
  color: #1565C0;
}

.tab-item.active {
  color: #1565C0;
  font-weight: 600;
  background: rgba(33, 150, 243, 0.05);
}

.tab-item.active::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 3px;
  background: linear-gradient(90deg, #2196F3 0%, #64B5F6 100%);
  box-shadow: none;
}

.mindmap-container,
.knowledge-graph-container {
  flex: 1;
  overflow: auto;
  padding: 20px;
  background: #FFFFFF;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
}

.mindmap-content,
.knowledge-graph-content {
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.mindmap-placeholder,
.knowledge-graph-placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  text-align: center;
  color: #666;
  width: 100%;
}

.mindmap-placeholder h3,
.knowledge-graph-placeholder h3 {
  margin: 16px 0 8px;
  font-size: 18px;
  color: #1565C0;
  font-weight: 600;
}

.mindmap-placeholder p,
.knowledge-graph-placeholder p {
  margin-bottom: 20px;
  color: #999;
}

.mindmap-icon {
  color: #2196F3;
  margin-bottom: 8px;
}

.knowledge-graph-icon {
  color: #1976D2;
  margin-bottom: 8px;
}

.mindmap-visualization,
.knowledge-graph-visualization {
  height: 100%;
  display: flex;
  flex-direction: column;
}

.mindmap-loading,
.knowledge-graph-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  height: 100%;
  color: #2196F3;
  font-weight: 500;
}

.mindmap-canvas,
.knowledge-graph-canvas {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(33, 150, 243, 0.1);
  overflow: auto;
  position: relative;
}

.mindmap-svg,
.knowledge-graph-svg {
  width: 100%;
  height: 100%;
  max-width: none;
  max-height: none;
  cursor: grab;
}

.mindmap-center-node {
  filter: drop-shadow(0 2px 4px rgba(33, 150, 243, 0.2));
}

.mindmap-branch-node {
  filter: drop-shadow(0 1px 2px rgba(33, 150, 243, 0.1));
}

.mindmap-line {
  opacity: 0.7;
}

.knowledge-graph-line {
  opacity: 0.5;
}

.knowledge-graph-node {
  filter: drop-shadow(0 2px 4px rgba(33, 150, 243, 0.15));
}

@media (max-width: 1024px) {
  .ai-sidebar {
    border-left: none;
    border-top: 1px solid rgba(33, 150, 243, 0.15);
    flex-direction: row;
  }

  .sidebar-tabs {
    flex-direction: column;
    min-width: 100px;
  }

  .tab-item {
    padding: 12px 0;
    font-size: 13px;
  }

  .tab-item.active::after {
    width: 2px;
    height: 100%;
    left: 0;
    bottom: auto;
  }
}

@media (max-width: 768px) {
  .ai-sidebar {
    border-left: none;
    border-top: 1px solid rgba(33, 150, 243, 0.15);
    flex-direction: column;
    height: auto;
    max-height: none;
    margin: 0;
    padding: 0;
  }

  .sidebar-tabs {
    flex-direction: row;
    flex: none;
    overflow-x: auto;
    height: 48px;
    margin: 0;
    padding: 0;
  }

  .mindmap-container,
  .knowledge-graph-container {
    display: flex;
    flex: 1;
    overflow: auto;
  }

  .tab-item {
    padding: 12px 8px;
    font-size: 12px;
    gap: 3px;
    flex: 1;
  }
  
  .tab-item :deep(.el-icon) {
    font-size: 16px;
  }

  .tab-item.active::after {
    width: 100%;
    height: 2px;
    left: 0;
    bottom: 0;
  }
}

@media (max-width: 480px) {
  .ai-sidebar {
    border-left: none;
    border-top: 1px solid rgba(33, 150, 243, 0.15);
    border-radius: 12px 12px 0 0;
    flex-direction: column;
    position: relative;
    height: auto;
    max-height: none;
    width: 100%;
    z-index: 999;
    box-shadow: 0 -4px 12px rgba(33, 150, 243, 0.1);
  }

  .sidebar-tabs {
    flex-direction: row;
    flex: none;
    height: 48px;
    background: linear-gradient(90deg, #F0F5FF 0%, #F5F9FF 100%);
    border-bottom: 1px solid rgba(33, 150, 243, 0.15);
    border-radius: 12px 12px 0 0;
    overflow-x: auto;
    margin: 0;
    padding: 0;
  }

  .tab-item {
    padding: 12px 8px;
    font-size: 12px;
    gap: 4px;
    flex: 1;
  }

  .tab-item :deep(.el-icon) {
    font-size: 16px;
  }

  .tab-item.active::after {
    width: 100%;
    height: 2px;
    left: 0;
    bottom: 0;
  }
}

@media (max-width: 375px) {
  .tab-item {
    padding: 8px 4px;
    font-size: 10px;
    gap: 2px;
    min-width: 60px;
  }
  
  .tab-item :deep(.el-icon) {
    font-size: 12px;
  }
}

@media (max-width: 320px) {
  .sidebar-tabs {
    height: 44px;
  }
  
  .tab-item {
    padding: 6px 2px;
    font-size: 9px;
    gap: 1px;
    min-width: 50px;
  }
  
  .tab-item :deep(.el-icon) {
    font-size: 11px;
  }
}
</style>
