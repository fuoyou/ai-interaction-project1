<template>
  <el-dialog
    v-model="visible"
    title="智能考点检测"
    width="90%"
    :style="{ maxWidth: '500px' }"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    :show-close="false"
    center
    class="checkpoint-dialog"
  >
    <div class="checkpoint-content">
      <div class="checkpoint-header">
        <el-tag class="flag-tag" size="large">
          <el-icon><Flag /></el-icon> 核心考点
        </el-tag>
        <p class="checkpoint-tip">请回答以下问题后继续学习</p>
      </div>

      <div class="question-section glass-box">
        <div class="question-title">{{ checkpoint.question }}</div>
        
        <!-- 选择题 -->
        <el-radio-group v-if="checkpoint.type === 'choice'" v-model="userAnswer" class="answer-options">
          <el-radio 
            v-for="(option, index) in checkpoint.options" 
            :key="index" 
            :label="option"
            :disabled="answered"
            border
          >
            {{ option }}
          </el-radio>
        </el-radio-group>

        <!-- 判断题 -->
        <el-radio-group v-else-if="checkpoint.type === 'judge'" v-model="userAnswer" class="answer-options">
          <el-radio label="正确" :disabled="answered" border>✓ 正确</el-radio>
          <el-radio label="错误" :disabled="answered" border>✗ 错误</el-radio>
        </el-radio-group>

        <!-- 简答题 -->
        <el-input
          v-else
          v-model="userAnswer"
          type="textarea"
          :rows="4"
          placeholder="请输入你的答案..."
          :disabled="answered"
          class="glass-textarea"
        />
      </div>

      <!-- 答案解析 -->
      <transition name="fade">
        <div v-if="answered" class="analysis-section glass-box">
          <el-alert
            :title="isCorrect ? '✓ 回答正确！' : '✗ 回答错误'"
            :type="isCorrect ? 'success' : 'error'"
            :closable="false"
            show-icon
          />
          <div class="analysis-content">
            <div class="analysis-label">正确答案：</div>
            <div class="analysis-text">{{ checkpoint.correctAnswer }}</div>
            <div class="analysis-label">解析：</div>
            <div class="analysis-text">{{ checkpoint.explanation }}</div>
          </div>
        </div>
      </transition>
    </div>

    <template #footer>
      <div class="dialog-footer">
        <el-button v-if="!answered" class="submit-btn" type="primary" @click="submitAnswer" :disabled="!userAnswer">
          提交答案
        </el-button>
        <el-button v-else type="success" class="continue-btn" @click="continueLearn">
          我已理解，继续学习 →
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, watch } from 'vue'
import { Flag } from '@element-plus/icons-vue'

const props = defineProps({
  modelValue: Boolean,
  checkpoint: {
    type: Object,
    default: () => ({ question: '', type: 'choice', options: [], correctAnswer: '', explanation: '' })
  }
})

const emit = defineEmits(['update:modelValue', 'continue'])

const visible = ref(false)
const userAnswer = ref('')
const answered = ref(false)
const isCorrect = ref(false)

watch(() => props.modelValue, (val) => {
  visible.value = val
  if (val) { userAnswer.value = ''; answered.value = false; isCorrect.value = false }
})

watch(visible, (val) => emit('update:modelValue', val))

const submitAnswer = () => {
  if (!userAnswer.value) return
  answered.value = true
  isCorrect.value = props.checkpoint.type === 'short' 
    ? userAnswer.value.includes(props.checkpoint.correctAnswer) 
    : userAnswer.value === props.checkpoint.correctAnswer
}

const continueLearn = () => {
  visible.value = false
  emit('continue')
}
</script>

<style scoped>
/* 弹窗：泛雅企业风格 */
:deep(.checkpoint-dialog .el-dialog) {
  background: linear-gradient(135deg, #F5FAFE 0%, #F0F5FF 100%);
  backdrop-filter: blur(10px);
  border-radius: 8px;
  border: 1px solid #E3F2FD;
  box-shadow: 0 4px 20px rgba(33, 150, 243, 0.08);
}

:deep(.checkpoint-dialog .el-dialog__title) {
  font-size: 16px;
  font-weight: 600;
  color: #1565C0;
}

.checkpoint-header { 
  text-align: center; 
  margin-bottom: 20px; 
}

.flag-tag { 
  background: linear-gradient(90deg, #2196F3 0%, #64B5F6 100%) !important; 
  border: none !important; 
  color: #FFFFFF !important;
}

.checkpoint-tip { 
  margin-top: 10px; 
  font-size: 13px; 
  color: #5C626E; 
}

.glass-box {
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(4px);
  border: 1px solid rgba(33, 150, 243, 0.15);
  padding: 20px;
  border-radius: 8px;
  margin-bottom: 20px;
}

.question-title { 
  font-size: 16px; 
  font-weight: 600; 
  color: #1565C0; 
  margin-bottom: 15px; 
}

.answer-options :deep(.el-radio.is-bordered) {
  border-radius: 6px;
  border: 1px solid rgba(33, 150, 243, 0.2);
  transition: all 0.3s;
}

.answer-options :deep(.el-radio.is-bordered.is-checked) {
  border-color: #2196F3;
  background: rgba(33, 150, 243, 0.08);
}

.analysis-text {
  color: #303133;
  line-height: 1.6;
  padding: 12px;
  background: rgba(33, 150, 243, 0.05);
  border-radius: 6px;
  margin-top: 5px;
  border-left: 3px solid #2196F3;
}

.submit-btn {
  background: linear-gradient(90deg, #2196F3 0%, #64B5F6 100%) !important;
  border: none !important;
  padding: 10px 30px;
}

.continue-btn {
  background: linear-gradient(90deg, #1976D2 0%, #2196F3 100%) !important;
  border: none !important;
}

.fade-enter-active, .fade-leave-active { 
  transition: opacity 0.3s; 
}

.fade-enter-from, .fade-leave-to { 
  opacity: 0; 
}

/* 响应式设计 - 平板 */
@media (max-width: 768px) {
  :deep(.checkpoint-dialog .el-dialog) {
    width: 95% !important;
    margin: auto !important;
  }

  .glass-box {
    padding: 16px;
    margin-bottom: 16px;
  }

  .question-title { 
    font-size: 15px; 
    margin-bottom: 12px; 
  }

  .submit-btn {
    padding: 8px 24px;
  }

  .checkpoint-tip { 
    font-size: 12px; 
  }
}

/* 响应式设计 - 手机 */
@media (max-width: 480px) {
  :deep(.checkpoint-dialog .el-dialog) {
    width: 98% !important;
    margin: auto !important;
  }

  .checkpoint-header { 
    margin-bottom: 16px; 
  }

  .glass-box {
    padding: 14px;
    margin-bottom: 14px;
  }

  .question-title { 
    font-size: 14px; 
    margin-bottom: 10px; 
  }

  .answer-options :deep(.el-radio.is-bordered) {
    display: block;
    margin-bottom: 8px;
    width: 100%;
  }

  .submit-btn,
  .continue-btn {
    padding: 8px 20px;
    font-size: 14px;
  }

  .checkpoint-tip { 
    font-size: 12px; 
  }

  .analysis-text {
    padding: 10px;
    font-size: 13px;
  }
}
</style>
