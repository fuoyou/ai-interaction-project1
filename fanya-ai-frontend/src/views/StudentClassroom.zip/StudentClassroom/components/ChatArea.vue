<template>
  <div class="chat-area" ref="scrollRef">
    <!-- 1. 讲解模式 -->
    <div v-if="mode === 'lecture'" class="ai-message">
      <div class="avatar"><img src="https://cdn-icons-png.flaticon.com/512/4712/4712027.png" /></div>
      <div class="message-content">
        <div class="ai-name">AI 讲师</div>
        <div class="bubble lecture-bubble">
          <p v-html="displayContent"></p>
        </div>
      </div>
    </div>

    <!-- 2. 问答模式 -->
    <div v-else class="chat-list">
      <div v-for="(msg, index) in history" :key="index" :class="['message-row', msg.role]">
        <!-- AI 头像 -->
        <div class="avatar" v-if="msg.role === 'ai'">
          <img src="https://cdn-icons-png.flaticon.com/512/4712/4712027.png" />
        </div>
        
        <div class="msg-content-wrapper" @mouseup="handleChatTextSelection($event, msg)">
          <!-- 普通文本消息 -->
          <div v-if="msg.type !== 'supplement'" class="bubble">
            <div v-html="formatMarkdown(msg.content)"></div>
            <!-- 【新增】如果消息来自文本选中，显示跳转按钮 -->
            <div v-if="msg.role === 'ai' && msg.sourcePage" class="jump-to-page">
              <el-button 
                size="small" 
                type="primary" 
                @click="$emit('jumpToPage', msg.sourcePage)"
              >
                <el-icon><Position /></el-icon> 跳转到第 {{ msg.sourcePage }} 页
              </el-button>
            </div>
          </div>
          
          <!-- 降维讲解卡片 -->
          <div v-else class="supplement-card">
            <div class="card-header">
              <el-icon><MagicStick /></el-icon> 节奏调整：AI 降维解析
            </div>
            <div class="card-body" v-html="formatMarkdown(msg.content)"></div>
            <div class="card-action">
              <el-button size="small" type="primary" plain @click="$emit('resolve', index)"  v-if="!msg.resolved">
                我理解了，继续讲解
              </el-button>
              <span v-else class="resolved-txt"><el-icon><Select /></el-icon> 已掌握</span>
            </div>
          </div>
        </div>

        <!-- 用户头像 -->
        <div class="avatar" v-if="msg.role === 'user'">
          <el-avatar :size="32" src="https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png" />
        </div>
      </div>

      <!-- 【新增】正在回答时的动效提示 -->
      <div v-if="isChatLoading" class="message-row ai loading-row">
        <div class="avatar">
          <img src="https://cdn-icons-png.flaticon.com/512/4712/4712027.png" />
        </div>
        <div class="msg-content-wrapper">
          <div class="bubble loading-bubble">
            <span class="loading-dot"></span>
            <span class="loading-dot"></span>
            <span class="loading-dot"></span>
            <span class="loading-text">AI 正在深度思考...</span>
          </div>
        </div>
      </div>

    </div>
  </div>
</template>


<script setup>
import { ref, watch, onUnmounted, nextTick } from 'vue'
import { MagicStick, Select, Position } from '@element-plus/icons-vue'
import katex from 'katex'
import 'katex/dist/katex.min.css'

const props = defineProps(['mode', 'script', 'audioUrl', 'history', 'isChatLoading'])

const displayContent = ref('')
const scrollRef = ref(null)
let typeTimer = null
let currentAudio = null
const emit = defineEmits(['resolve', 'speakContent', 'jumpToPage', 'chatTextSelected'])
// --- 断点记录状态 ---
const pausedTime = ref(0)
const pausedIndex = ref(0)
const lastAudioUrl = ref('')

// --- 防抖：避免重复触发文本选择 ---
let textSelectionTimeout = null
const isProcessingSelection = ref(false)

// --- 处理聊天消息文本选择 ---
const handleChatTextSelection = (event, msg) => {
  // 只处理AI消息的选择
  if (msg.role !== 'ai') return
  
  // 如果正在处理选择，忽略
  if (isProcessingSelection.value) return
  
  const selection = window.getSelection()
  const selectedText = selection?.toString().trim()
  
  if (selectedText && selectedText.length > 3) {
    // 阻止事件冒泡
    event.stopPropagation()
    
    // 清除之前的定时器
    if (textSelectionTimeout) {
      clearTimeout(textSelectionTimeout)
    }
    
    isProcessingSelection.value = true
    
    textSelectionTimeout = setTimeout(() => {
      // 尝试从原始内容中提取对应的文本（包括LaTeX公式）
      let textToSend = selectedText
      
      // 如果原始消息包含公式标记，尝试匹配并保留
      if (msg.content.includes('$')) {
        // 简单策略：如果选中的文本看起来像公式符号，尝试从原始内容中查找
        const originalContent = msg.content
        
        // 查找是否有匹配的LaTeX公式
        const formulaRegex = /\$([^\$]+?)\$/g
        let match
        while ((match = formulaRegex.exec(originalContent)) !== null) {
          const latexFormula = match[1]
          // 渲染这个公式看看是否匹配选中的文本
          try {
            const rendered = katex.renderToString(latexFormula, { 
              throwOnError: false, 
              displayMode: false 
            })
            // 创建临时元素来提取纯文本
            const tempDiv = document.createElement('div')
            tempDiv.innerHTML = rendered
            const renderedText = tempDiv.textContent || tempDiv.innerText
            
            // 如果选中的文本包含这个渲染后的公式，替换为LaTeX格式
            if (selectedText.includes(renderedText.trim())) {
              textToSend = textToSend.replace(renderedText.trim(), `$${latexFormula}$`)
            }
          } catch (e) {
            // 忽略错误
          }
        }
      }
      
      emit('chatTextSelected', {
        text: textToSend,
        originalMessage: msg.content
      })
      selection.removeAllRanges()
      
      // 重置处理状态
      setTimeout(() => {
        isProcessingSelection.value = false
      }, 500)
    }, 300)
  }
}

// --- Markdown格式化函数 ---
const formatMarkdown = (text) => {
  if (!text) return ''
  
  let formatted = text
  
  // 临时占位符，用于保护公式和代码块不被其他规则处理
  const protectedContent = []
  let placeholderIndex = 0
  
  // 0. 先提取代码块（保护特殊符号）
  formatted = formatted.replace(/```([^`]+)```/g, (match, code) => {
    const placeholder = `__PROTECTED_${placeholderIndex}__`
    protectedContent[placeholderIndex] = `<pre style="background: #f5f5f5; padding: 8px; border-radius: 4px; overflow-x: auto; margin: 0.5em 0;"><code>${code.trim()}</code></pre>`
    placeholderIndex++
    return placeholder
  })
  
  // 行内代码
  formatted = formatted.replace(/`([^`]+)`/g, (match, code) => {
    const placeholder = `__PROTECTED_${placeholderIndex}__`
    protectedContent[placeholderIndex] = `<code style="background: #f5f5f5; padding: 2px 6px; border-radius: 3px; font-family: monospace;">${code}</code>`
    placeholderIndex++
    return placeholder
  })
  
  // 1. 提取并保存所有公式
  // 处理 \[ ... \] 块级公式
  formatted = formatted.replace(/\\\[([^\]]+?)\\\]/g, (match, formula) => {
    try {
      const rendered = katex.renderToString(formula.trim(), { 
        throwOnError: false, 
        displayMode: true 
      })
      const placeholder = `__PROTECTED_${placeholderIndex}__`
      protectedContent[placeholderIndex] = rendered
      placeholderIndex++
      return placeholder
    } catch (e) {
      console.error('KaTeX块级公式渲染失败:', e, formula)
      return match
    }
  })
  
  // 处理 \( ... \) 行内公式
  formatted = formatted.replace(/\\\(([^\)]+?)\\\)/g, (match, formula) => {
    try {
      const rendered = katex.renderToString(formula.trim(), { 
        throwOnError: false, 
        displayMode: false 
      })
      const placeholder = `__PROTECTED_${placeholderIndex}__`
      protectedContent[placeholderIndex] = rendered
      placeholderIndex++
      return placeholder
    } catch (e) {
      console.error('KaTeX行内公式渲染失败:', e, formula)
      return match
    }
  })
  
  // 处理块级公式 $$...$$
  formatted = formatted.replace(/\$\$([^\$]+?)\$\$/g, (match, formula) => {
    try {
      const rendered = katex.renderToString(formula.trim(), { 
        throwOnError: false, 
        displayMode: true 
      })
      const placeholder = `__PROTECTED_${placeholderIndex}__`
      protectedContent[placeholderIndex] = rendered
      placeholderIndex++
      return placeholder
    } catch (e) {
      console.error('KaTeX块级公式渲染失败:', e, formula)
      return match
    }
  })
  
  // 处理行内公式 $...$
  formatted = formatted.replace(/\$([^\$\n]+?)\$/g, (match, formula) => {
    try {
      const rendered = katex.renderToString(formula.trim(), { 
        throwOnError: false, 
        displayMode: false 
      })
      const placeholder = `__PROTECTED_${placeholderIndex}__`
      protectedContent[placeholderIndex] = rendered
      placeholderIndex++
      return placeholder
    } catch (e) {
      console.error('KaTeX行内公式渲染失败:', e, formula)
      return match
    }
  })
  
  // 2. 处理加粗 **text** 或 __text__
  formatted = formatted.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
  // 注意：不处理 __ 作为加粗，因为它可能是占位符的一部分
  
  // 3. 处理斜体 *text* 或 _text_
  formatted = formatted.replace(/\*([^*]+?)\*/g, '<em>$1</em>')
  // 注意：不处理 _ 作为斜体，因为它可能是占位符的一部分
  
  // 4. 处理换行（在恢复占位符之前）
  formatted = formatted.replace(/\n/g, '<br>')
  
  // 5. 处理列表项 - 数字列表
  formatted = formatted.replace(/^(\d+)\.\s+(.+)$/gm, '<div style="margin-left: 1em; margin-top: 0.5em;">$1. $2</div>')
  
  // 6. 处理列表项 - 无序列表
  formatted = formatted.replace(/^[-*]\s+(.+)$/gm, '<div style="margin-left: 1em; margin-top: 0.5em;">• $1</div>')
  
  // 7. 最后恢复所有受保护的内容（公式和代码块）
  protectedContent.forEach((content, index) => {
    const placeholder = `__PROTECTED_${index}__`
    formatted = formatted.replace(new RegExp(placeholder, 'g'), content)
  })
  
  return formatted
}

// --- 打字机效果（恢复流式输出） ---
const startTyping = (fullText, startIndex = 0) => {
  if (!fullText) return;
  
  if (startIndex === 0) {
    displayContent.value = '';
  }
  
  let i = startIndex;
  if (typeTimer) clearInterval(typeTimer);
  
  typeTimer = setInterval(() => {
    const rawText = fullText.slice(0, i + 1);
    displayContent.value = formatMarkdown(rawText);
    i++;
    
    pausedIndex.value = i;

    scrollToBottom();
    if (i >= fullText.length) {
      clearInterval(typeTimer);
      // 【关键修改】打字机完成后不清空断点，保留位置
      // clearBreakPoint();
      console.log(`[打字机] 完成，保留断点位置: ${pausedIndex.value}`);
    }
  }, 50);
}

// 清除断点
const clearBreakPoint = () => {
  pausedTime.value = 0;
  pausedIndex.value = 0;
}

const scrollToBottom = () => {
  nextTick(() => {
    if (scrollRef.value) {
      scrollRef.value.scrollTop = scrollRef.value.scrollHeight;
    }
  });
}

// --- 模式切换监听 ---
watch(() => props.mode, (newMode, oldMode) => {
  if (oldMode === 'lecture' && newMode === 'chat') {
    if (currentAudio) {
      pausedTime.value = currentAudio.currentTime;
      currentAudio.pause();
    }
    if (typeTimer) clearInterval(typeTimer);
    console.log(`[打断] 已记录位置：时间 ${pausedTime.value}s, 索引 ${pausedIndex.value}`);
  } 
  
  else if (newMode === 'lecture') {
    if (props.script) {
      console.log(`[恢复] 显示讲解内容`);
      startTyping(props.script, pausedIndex.value);
    }
  }
});

// --- 翻页监听 ---
watch(() => props.audioUrl, (newUrl) => {
  if (newUrl !== lastAudioUrl.value) {
    // 只有真正翻页时才清空断点
    clearBreakPoint();
    lastAudioUrl.value = newUrl;
    if (props.mode === 'lecture' && newUrl) {
      startTyping(props.script, 0);
    }
  }
}, { immediate: true });

// --- 问答历史监听 ---
watch(() => props.history, () => {
  if (props.mode === 'chat') {
    scrollToBottom();
  }
}, { deep: true });

// --- 讲稿内容监听（不触发数字人播放，由 DigitalAvatar 组件的 watch 处理）---
watch(() => props.script, (newVal) => {
  // 1. 如果收到了空字符串（由 index.vue 的 startLecture 触发）
  if (newVal === '') {
    if (currentAudio) currentAudio.pause();
    if (typeTimer) clearInterval(typeTimer);
    
    clearBreakPoint();
    displayContent.value = '';
    return;
  }

  // 2. 如果是正常的内容加载或恢复（使用打字机效果）
  if (props.mode === 'lecture' && newVal) {
    startTyping(newVal, pausedIndex.value);
  }
}, { immediate: true });


onUnmounted(() => {
  if (currentAudio) currentAudio.pause();
  if (typeTimer) clearInterval(typeTimer);
});
</script>

<style scoped>
.chat-area { flex: 1; overflow-y: auto; padding: 20px 20px 20px 20px; background-color: #ffffff; scroll-behavior: smooth; margin-top: 12px; }
.ai-message { display: flex; gap: 12px; }
.avatar img { width: 32px; height: 32px; border-radius: 50%; }
.message-content { flex: 1; }
.ai-name { font-size: 12px; color: #999; margin-bottom: 4px; }
.bubble { 
  padding: 10px 14px; 
  border-radius: 8px; 
  font-size: 14px; 
  line-height: 1.5; 
  background: #fff; 
  word-wrap: break-word;
  user-select: text;
  -webkit-user-select: text;
  -moz-user-select: text;
  cursor: text;
}

/* 【新增】Markdown格式化样式 */
.bubble :deep(strong) {
  font-weight: 600;
  color: #333;
}

.bubble :deep(em) {
  font-style: italic;
  color: #666;
}

.bubble :deep(br) {
  display: block;
  content: "";
  margin: 0.5em 0;
}

/* 【新增】数学公式样式 */
.bubble :deep(.katex) {
  font-size: 1.1em;
  user-select: text;
  -webkit-user-select: text;
  -moz-user-select: text;
  cursor: text;
}

.bubble :deep(.katex-display) {
  margin: 1em 0;
  text-align: center;
  user-select: text;
  -webkit-user-select: text;
}

.bubble :deep(.katex-html) {
  color: #333;
  user-select: text;
  -webkit-user-select: text;
}

.bubble :deep(.katex *) {
  user-select: text;
  -webkit-user-select: text;
}

.lecture-bubble { border-radius: 0 12px 12px 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
.message-row { display: flex; gap: 10px; margin-bottom: 20px; }
.message-row.user { flex-direction: row-reverse; }
.message-row.user .bubble { background: #0077ff; color: #fff; border-radius: 12px 0 12px 12px; }

/* 模块3样式 */
.msg-content-wrapper { max-width: 85%; }
.supplement-card { background: #fffbe6; border: 1px solid #ffe58f; border-radius: 10px; padding: 15px; box-shadow: 0 4px 12px rgba(250, 173, 20, 0.1); }
.card-header { color: #fa8c16; font-weight: bold; font-size: 13px; margin-bottom: 8px; display: flex; align-items: center; gap: 6px; }
.card-body { font-size: 13px; color: #595959; line-height: 1.6; }
.card-action { display: flex; justify-content: flex-end; margin-top: 10px; }
.resolved-txt { font-size: 12px; color: #52c41a; font-weight: bold; display: flex; align-items: center; gap: 4px; }

/* 【新增】跳转按钮样式 */
.jump-to-page {
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px solid rgba(0, 119, 255, 0.1);
}

.jump-to-page :deep(.el-button) {
  padding: 8px 16px;
  font-size: 13px;
  font-weight: 500;
  white-space: nowrap;
}

.loading-row { margin-top: 10px; }
.loading-bubble { 
  display: flex; align-items: center; gap: 5px; 
  padding: 12px 18px; background: #fff; color: #666; font-size: 13px; 
}
.loading-dot {
  width: 6px; height: 6px; background-color: #0077ff; border-radius: 50%;
  animation: bounce 1.4s infinite ease-in-out both;
}
.loading-dot:nth-child(1) { animation-delay: -0.32s; }
.loading-dot:nth-child(2) { animation-delay: -0.16s; }
.loading-text { margin-left: 8px; color: #999; font-size: 12px; }

@keyframes bounce {
  0%, 80%, 100% { transform: scale(0); }
  40% { transform: scale(1); }
}
</style>