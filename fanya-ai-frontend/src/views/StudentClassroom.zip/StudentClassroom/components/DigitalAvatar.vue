<template>
  <div class="digital-avatar-fullscreen">
    <div class="avatar-container">
      <iframe 
        ref="avatarIframe"
        src="http://localhost:3000/sentio" 
        frameborder="0"
        class="avatar-iframe"
        scrolling="no"
        @load="onIframeLoad"
      ></iframe>
      <div class="overlay-top"></div>
      <div class="overlay-bottom"></div>
    </div>

    <!-- 左下角主控制面板 -->
    <div class="control-panel">
      <div class="panel-header">
        <span class="title"><el-icon><VideoCamera /></el-icon> AI 数字讲师</span>
      </div>
      <div class="panel-content">
        <div class="status-info" v-if="isSpeaking">
          <div class="pulse-dot"></div><span>正在实时讲解...</span>
        </div>
        <div class="status-info paused" v-else-if="isPaused">
          <div class="pause-icon">||</div><span>已暂停答疑中</span>
        </div>
        <div class="status-info ready" v-else>
          <div class="static-dot"></div><span>AI 讲师已就绪</span>
        </div>
        
        <!-- 【新增】手势控制按钮 -->
        <el-button 
          size="small" 
          type="info" 
          round
          plain
          @click="toggleGesturePanel" 
          class="gesture-btn"
        >
          <el-icon><Operation /></el-icon> 手势控制
        </el-button>
      </div>
    </div>

    <!-- 【新增】手势控制悬浮面板 -->
    <transition name="slide-up">
      <div v-show="showGesturePanel" class="gesture-panel">
        <div class="gesture-header">
          <span class="header-title">✨ 快捷手势</span>
          <el-icon @click="showGesturePanel = false" class="close-icon"><Close /></el-icon>
        </div>
        <div class="gesture-buttons">
          <el-button @click="setGesture('wave')">
            <span class="gesture-emoji">👋</span> 挥手
          </el-button>
          <el-button @click="setGesture('pointLeft')">
            <span class="gesture-emoji">👈</span> 指左
          </el-button>
          <el-button @click="setGesture('pointRight')">
            <span class="gesture-emoji">👉</span> 指右
          </el-button>
          <el-button @click="setGesture('welcome')">
            <span class="gesture-emoji">🤗</span> 欢迎
          </el-button>
          <el-button @click="setGesture('thinking')">
            <span class="gesture-emoji">🤔</span> 思考
          </el-button>
          <el-button @click="setGesture('reset')">
            <span class="gesture-emoji">↺</span> 重置
          </el-button>
        </div>
      </div>
    </transition>
  </div>
</template>

<script setup>
import { ref, watch, onMounted, onUnmounted } from 'vue'
import { ElMessage } from 'element-plus'
import { VideoCamera, Operation, Close } from '@element-plus/icons-vue'

const props = defineProps({
  script: String,
  page: Number,
  speakText: String,
  mode: String,
  totalPages: Number
})

const emit = defineEmits(['autoNextPage', 'speaking'])

// 基础状态 Refs
const avatarIframe = ref(null)
const isSpeaking = ref(false)
const isPaused = ref(false)
const lastSpokenScript = ref('')
const iframeReady = ref(false)
const pendingScript = ref('')

// 新增状态 Refs
const showGesturePanel = ref(false)

// 手势保持定时器
let gestureKeepAliveTimer = null
const currentGesture = ref('pointLeft')

// 【新增】预设手势库
const gesturePresets = {
  wave: { rightHand: 0.5, rightArmA: 8.0, rightArmB: 5.0 },
  pointLeft: { leftHand: -0.8, leftArmA: 6.0, leftArmB: 8.0 },
  pointRight: { rightHand: -0.8, rightArmA: 6.0, rightArmB: 8.0 },
  pointPPT: { leftHand: -0.8, leftArmA: 6.0, leftArmB: 8.0, rightHand: 0.2, rightArmA: 0.5, rightArmB: 0.5 },
  welcome: { leftHand: -0.5, rightHand: -0.5, leftArmA: 7.0, rightArmA: 7.0, leftArmB: 4.0, rightArmB: 4.0 },
  thinking: { rightHand: 0.3, rightArmA: 5.0, rightArmB: 8.0 },
  reset: { leftHand: 0, rightHand: 0, leftArmA: 0, rightArmA: 0, leftArmB: 0, rightArmB: 0 }
}

// 【新增】关键词到手势的智能映射
const keywordGestureMap = {
  '欢迎': 'welcome', '大家好': 'wave', '你好': 'wave',
  '左边': 'pointLeft', '左侧': 'pointLeft', '这边': 'pointLeft',
  '右边': 'pointRight', '右侧': 'pointRight', '那边': 'pointRight',
  '思考': 'thinking', '想一想': 'thinking', '考虑': 'thinking'
}

// 获取手势中文名称
const getGestureName = (gesture) => {
  const names = { wave: '挥手', pointLeft: '指向左侧', pointRight: '指向右侧', pointPPT: '指向课件', welcome: '欢迎', thinking: '思考', reset: '重置' }
  return names[gesture] || gesture
}

// 发送消息到 iframe
const postMsg = (type, data = {}) => {
  if (avatarIframe.value && iframeReady.value) {
    avatarIframe.value.contentWindow.postMessage({ type, ...data }, '*')
  }
}

// 强制停止所有播放
const forceStopAll = () => {
  // 停止浏览器原生语音合成
  window.speechSynthesis.cancel()
  // 停止 iframe 内的音频
  postMsg('STOP_SPEAK')
  // 重置状态
  isSpeaking.value = false
  isPaused.value = true
  emit('speaking', false)
  console.log('[数字人] 强制停止所有播放')
}

// 【新增】触发手势动作
const setGesture = (gestureName) => {
  const gesture = gesturePresets[gestureName]
  if (gesture && iframeReady.value) {
    postMsg('SET_HAND_GESTURE', { gesture })
    console.log('[数字人] 设置手势:', getGestureName(gestureName))
    // 记录当前手势
    currentGesture.value = gestureName
  }
}

// 【新增】启动手势保持定时器
const startGestureKeepAlive = () => {
  // 清除旧的定时器
  if (gestureKeepAliveTimer) {
    clearInterval(gestureKeepAliveTimer)
  }
  // 每2秒重新发送一次手势指令，确保手势不被Live2D的Idle动画覆盖
  gestureKeepAliveTimer = setInterval(() => {
    if (iframeReady.value && currentGesture.value) {
      const gesture = gesturePresets[currentGesture.value]
      if (gesture) {
        postMsg('SET_HAND_GESTURE', { gesture })
        console.log('[数字人] 保持手势:', getGestureName(currentGesture.value))
      }
    }
  }, 2000)
}

// 【新增】停止手势保持定时器
const stopGestureKeepAlive = () => {
  if (gestureKeepAliveTimer) {
    clearInterval(gestureKeepAliveTimer)
    gestureKeepAliveTimer = null
  }
}

// 【新增】根据文本内容智能匹配手势
const matchGestureFromText = (text) => {
  if (!text) return null
  for (const [keyword, gesture] of Object.entries(keywordGestureMap)) {
    if (text.includes(keyword)) return gesture
  }
  return null
}

// 【新增】带手势的讲解逻辑
const speakWithGesture = (text, gesture = null, isInterrupt = false) => {
  // 强制使用指向左侧的手势（pointLeft）
  const targetGesture = 'pointLeft'
  setGesture(targetGesture)
  
  // 延迟 300ms 再开始讲话，让手势动画更自然
  setTimeout(() => {
    isSpeaking.value = true
    emit('speaking', true)
    postMsg('DIRECT_SPEAK', { text, isInterrupt })
  }, 300)
}

// iframe 加载完毕事件
const onIframeLoad = () => {
  console.log("[数字人] iframe 加载完成");
  iframeReady.value = true;

  // 【优化】加载完成后默认指向课件
  setGesture('pointLeft');
  // 启动手势保持定时器
  startGestureKeepAlive();

  // 处理组件挂载时未就绪的讲稿
  if (pendingScript.value && props.mode === 'lecture') {
    speakWithGesture(pendingScript.value);
    pendingScript.value = '';
  }
}

// 监听模式切换
watch(() => props.mode, (newMode, oldMode) => {
  if (oldMode === 'lecture' && newMode === 'chat') {
    // 切换到"我要提问"模式或题目弹窗：立即停止当前音频
    forceStopAll();
    // 【关键修复】停止手势保持定时器
    stopGestureKeepAlive();
    // 【关键修复】设置思考手势并保持
    setGesture('thinking'); // 暂停时做思考动作
    // 【新增】在chat模式下也保持思考手势
    if (iframeReady.value) {
      gestureKeepAliveTimer = setInterval(() => {
        const gesture = gesturePresets['thinking']
        if (gesture) {
          postMsg('SET_HAND_GESTURE', { gesture })
          console.log('[数字人] 保持思考手势')
        }
      }, 2000)
    }
    console.log('[数字人] 切换到提问模式/题目弹窗，已停止音频');
  } 
  else if (newMode === 'lecture' && oldMode === 'chat') {
    // 切换回"伴随讲解"模式：从当前页重新开始讲解
    isPaused.value = false;
    // 【关键修复】停止chat模式的思考手势定时器
    stopGestureKeepAlive();
    setGesture('pointLeft'); // 恢复时指向课件
    // 【关键修复】重新启动手势保持定时器
    startGestureKeepAlive();
    // 不立即播放，等待 script 变化触发
    console.log('[数字人] 切换回讲解模式，等待讲稿触发');
  }
})

// 监听 AI 插播回答（问答模式 - 不触发数字人讲解）
watch(() => props.speakText, (newText, oldText) => {
  if (newText && newText.length > 0 && newText !== oldText) {
    // 确保在任何情况下都停止当前播放
    if (props.mode === 'chat') {
      forceStopAll();
      console.log('[数字人] 收到AI回答/题目弹窗，停止当前播放');
    }
  }
})
// 监听页码变化，确保讲稿和页码同步
watch(() => props.page, (newPage, oldPage) => {
  console.log(`[数字人] 页码变化: ${oldPage} -> ${newPage}`);
  // 页码变化时重置 lastSpokenScript，确保新页面的讲稿能播放
  if (newPage !== oldPage) {
    lastSpokenScript.value = '';
  }
});

// 监听讲稿变化（自动翻页播报）
watch(() => props.script, (newText, oldText) => {
  // 只在讲解模式下且未暂停时才播放
  if (props.mode === 'lecture' && !isPaused.value && newText && newText.length > 5) {
    if (newText !== oldText) {
      lastSpokenScript.value = '';
    }
    // 讲稿去重防抖处理
    if (newText !== lastSpokenScript.value) {
      lastSpokenScript.value = newText;
      if (!iframeReady.value) {
        pendingScript.value = newText; // 若未加载完则暂存
      } else {
        speakWithGesture(newText); // 使用带手势的播报
      }
    }
  } else if (props.mode === 'chat') {
    // 在 chat 模式下（包括题目弹窗），确保停止任何播放
    forceStopAll();
    console.log('[数字人] 检测到 chat 模式，阻止播放');
  }
}, { immediate: true })

// 监听 iframe 返回的事件
const handleIframeMessage = (event) => {
  if (event.data && event.data.type === 'AUDIO_ENDED') {
    console.log("[数字人] 音频播放完成");
    isSpeaking.value = false;
    emit('speaking', false)
    setGesture('pointLeft'); // 【优化】音频结束自动指向课件

    if (props.mode === 'lecture' && !isPaused.value) {
      emit('autoNextPage');
    }
  }
}

// 手动触发播报
const triggerManualSpeak = () => {
  if (!props.script) return ElMessage.warning('当前页没有讲稿内容')
  speakWithGesture(props.script);
  ElMessage.success('已触发实时讲解');
}

// 切换手势面板显示状态
const toggleGesturePanel = () => {
  showGesturePanel.value = !showGesturePanel.value
}

onMounted(() => {
  window.addEventListener('message', handleIframeMessage);
})

onUnmounted(() => {
  window.removeEventListener('message', handleIframeMessage);
  // 清除手势保持定时器
  stopGestureKeepAlive();
})
</script>

<style scoped>
/* 原有基础样式 */
.digital-avatar-fullscreen { position: relative; width: 100%; height: 100%; background: linear-gradient(135deg, #E3F2FD 0%, #F5F9FF 100%); border-radius: 12px; overflow: hidden; box-shadow: 0 4px 16px rgba(33, 150, 243, 0.15); }
.avatar-container { width: 100%; height: 100%; position: relative; }
.avatar-iframe { width: 100%; height: 160%; margin-top: -46px; border: none; }
.overlay-top { position: absolute; top: 0; left: 0; width: 100%; height: 40px; background: transparent; z-index: 10; pointer-events: none; }
.overlay-bottom { position: absolute; bottom: 0; left: 0; width: 100%; height: 120px; background: linear-gradient(to top, rgba(227, 242, 253, 0.95) 0%, rgba(227, 242, 253, 0) 100%); z-index: 10; pointer-events: none; }
.control-panel { position: absolute; bottom: 20px; left: 20px; width: auto; background: rgba(255, 255, 255, 0.9); backdrop-filter: blur(8px); border-radius: 8px; border: 1px solid rgba(33, 150, 243, 0.2); box-shadow: 0 4px 16px rgba(33, 150, 243, 0.15); z-index: 20; transition: all 0.3s ease; padding: 8px 12px; }
.control-panel:hover { background: rgba(255, 255, 255, 0.95); transform: translateY(-2px); box-shadow: 0 6px 20px rgba(33, 150, 243, 0.2); }
.panel-header { padding: 0; background: transparent; border-bottom: none; display: none; }
.title { font-weight: 600; font-size: 12px; color: #1565C0; display: flex; align-items: center; gap: 6px; }
.panel-content { padding: 0; display: flex; flex-direction: row; gap: 6px; align-items: center; }
.status-info { display: flex; align-items: center; gap: 8px; font-size: 12px; color: #2196F3; font-weight: 500; padding: 6px 10px; background: rgba(33, 150, 243, 0.1); border-radius: 6px; border: 1px solid rgba(33, 150, 243, 0.25); }
.status-info.ready { color: #64B5F6; background: rgba(33, 150, 243, 0.08); border-color: rgba(33, 150, 243, 0.15); }
.status-info.paused { color: #FFA726; background: rgba(255, 167, 38, 0.12); border-color: rgba(255, 167, 38, 0.3); }
.pause-icon { font-weight: bold; font-size: 10px; letter-spacing: 1px; }
.pulse-dot { width: 8px; height: 8px; background: #2196F3; border-radius: 50%; box-shadow: 0 0 0 rgba(33, 150, 243, 0.4); animation: pulse 1.5s infinite; flex-shrink: 0; }
.static-dot { width: 8px; height: 8px; background: #64B5F6; border-radius: 50%; flex-shrink: 0; }
@keyframes pulse { 0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(33, 150, 243, 0.7); } 70% { transform: scale(1); box-shadow: 0 0 0 8px rgba(33, 150, 243, 0); } 100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(33, 150, 243, 0); } }

.speak-btn, .gesture-btn { width: auto; font-size: 12px; font-weight: 500; padding: 6px 10px !important; }

/* 【新增】手势面板样式 */
.gesture-panel {
  position: absolute; /* 修改为 absolute，相对于 digital-avatar-fullscreen */
  bottom: 80px;
  left: 50%;
  transform: translateX(-50%);
  width: 220px;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(12px);
  border-radius: 12px;
  border: 1px solid rgba(33, 150, 243, 0.25); 
  box-shadow: 0 8px 32px rgba(33, 150, 243, 0.15);
  overflow: hidden;
  z-index: 20;
}

.gesture-header {
  padding: 10px 16px;
  background: linear-gradient(90deg, #E3F2FD 0%, #F5F9FF 100%);
  border-bottom: 1px solid rgba(33, 150, 243, 0.15);
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: #1565C0;
  font-size: 13px;
  font-weight: 600;
}

.close-icon { cursor: pointer; font-size: 16px; color: #64B5F6; transition: color 0.3s; }
.close-icon:hover { color: #2196F3; }

.gesture-buttons {
  padding: 12px;
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 8px;
  background: #fff;
}

/* 覆盖 el-button 的默认内边距使其更紧凑 */
.gesture-buttons :deep(.el-button) {
  margin: 0;
  padding: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
}
.gesture-emoji { font-size: 14px; }

/* 动画效果 */
.slide-up-enter-active, .slide-up-leave-active { transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1); }
.slide-up-enter-from, .slide-up-leave-to { opacity: 0; transform: translate(-50%, 10px); }
</style>
