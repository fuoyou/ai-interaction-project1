<template>
  <div class="teacher-app">
    <TopHeader @nav="handleNavigation" @showCourseList="courseListDrawerVisible = true" />

    <div class="main-viewport" v-if="viewMode === 'workbench'">
      <!-- 桌面端：左侧侧边栏 -->
      <aside class="left-sidebar glass-panel sidebar-desktop" style="display: none;">
        <div class="upload-section">
          <el-upload
            action="#"
            :auto-upload="false"
            :on-change="handleFileUpload"
            :show-file-list="false"
            accept=".pdf,.ppt,.pptx"
            class="full-width-upload"
          >
            <el-button class="upload-btn" :loading="isUploading">
              <el-icon class="el-icon--left"><Plus /></el-icon>
              {{ isUploading ? '正在上传...' : '上传文件' }}
            </el-button>
          </el-upload>
        </div>
        <div class="search-box">
          <el-input v-model="searchKeyword" placeholder="搜索文件..." :prefix-icon="Search" class="glass-search" />
        </div>
        <div class="list-header">文件列表</div>

        <div class="file-list">
          <div v-if="loadingList" class="loading-state">
            <el-icon class="is-loading" color="#2196F3" :size="24"><Loading /></el-icon>
          </div>
          <div
            v-for="item in filteredList"
            :key="item.id"
            :class="['file-list-item', 'glass-item', { active: currentCourseId === item.id }]"
            @click="selectCourse(item)"
          >
            <div class="active-bar" v-if="currentCourseId === item.id"></div>
            <div class="file-card-content">
              <div class="file-icon-wrapper">
                <el-icon :size="24" color="#2196F3"><Document /></el-icon>
              </div>
              <div class="file-text-info">
                <div class="file-name" :title="item.courseName">{{ item.courseName }}</div>
                <div class="file-date">日期：{{ formatDate(item.updateTime) }}</div>
              </div>
            </div>
          </div>
          <el-empty v-if="!loadingList && filteredList.length === 0" description="暂无文件" :image-size="60" />
        </div>
      </aside>

      <!-- 移动端：抽屉菜单 -->
      <el-drawer
        v-model="sidebarDrawerVisible"
        title="文件列表"
        direction="ltr"
        size="280px"
        :lock-scroll="true"
        class="sidebar-drawer"
        @close="sidebarDrawerVisible = false"
      >
        <div class="drawer-content">
          <div class="upload-section">
            <el-upload
              action="#"
              :auto-upload="false"
              :on-change="handleFileUpload"
              :show-file-list="false"
              accept=".pdf,.ppt,.pptx"
              class="full-width-upload"
            >
              <el-button class="upload-btn" :loading="isUploading" size="small">
                <el-icon class="el-icon--left"><Plus /></el-icon>
                {{ isUploading ? '上传中...' : '上传文件' }}
              </el-button>
            </el-upload>
          </div>
          <div class="search-box">
            <el-input v-model="searchKeyword" placeholder="搜索文件..." :prefix-icon="Search" class="glass-search" size="small" />
          </div>

          <div class="file-list drawer-file-list">
            <div v-if="loadingList" class="loading-state">
              <el-icon class="is-loading" color="#2196F3" :size="24"><Loading /></el-icon>
            </div>
            <div
              v-for="item in filteredList"
              :key="item.id"
              :class="['file-list-item', { active: currentCourseId === item.id }]"
              @click="selectCourseAndClose(item)"
            >
              <div class="file-card-content">
                <div class="file-icon-wrapper">
                  <el-icon :size="20" color="#2196F3"><Document /></el-icon>
                </div>
                <div class="file-text-info">
                  <div class="file-name" :title="item.courseName">{{ item.courseName }}</div>
                  <div class="file-date">{{ formatDate(item.updateTime) }}</div>
                </div>
              </div>
            </div>
            <el-empty v-if="!loadingList && filteredList.length === 0" description="暂无文件" :image-size="60" />
          </div>
        </div>
      </el-drawer>

      <!-- 桌面端：课件列表抽屉 -->
      <el-drawer
        v-model="courseListDrawerVisible"
        title="课件列表"
        direction="ltr"
        size="320px"
        :lock-scroll="true"
        class="course-list-drawer"
      >
        <div class="drawer-content">
          <div class="upload-section">
            <el-upload
              action="#"
              :auto-upload="false"
              :on-change="handleFileUpload"
              :show-file-list="false"
              accept=".pdf,.ppt,.pptx"
              class="full-width-upload"
            >
              <el-button class="upload-btn" :loading="isUploading">
                <el-icon class="el-icon--left"><Plus /></el-icon>
                {{ isUploading ? '上传中...' : '上传文件' }}
              </el-button>
            </el-upload>
          </div>
          <div class="search-box">
            <el-input v-model="searchKeyword" placeholder="搜索文件..." :prefix-icon="Search" class="glass-search" />
          </div>

          <div class="file-list drawer-file-list">
            <div v-if="loadingList" class="loading-state">
              <el-icon class="is-loading" color="#2196F3" :size="24"><Loading /></el-icon>
            </div>
            <div
              v-for="item in filteredList"
              :key="item.id"
              :class="['file-list-item', { active: currentCourseId === item.id }]"
              @click="selectCourse(item); courseListDrawerVisible = false"
            >
              <div class="file-card-content">
                <div class="file-icon-wrapper">
                  <el-icon :size="24" color="#2196F3"><Document /></el-icon>
                </div>
                <div class="file-text-info">
                  <div class="file-name" :title="item.courseName">{{ item.courseName }}</div>
                  <div class="file-date">日期：{{ formatDate(item.updateTime) }}</div>
                </div>
              </div>
            </div>
            <el-empty v-if="!loadingList && filteredList.length === 0" description="暂无文件" :image-size="60" />
          </div>
        </div>
      </el-drawer>
      <main class="main-content glass-panel">
        <!-- 移动端菜单按钮 -->
        <button class="mobile-menu-btn" @click="toggleSidebar" v-if="isMobile">
          <el-icon :size="24"><Menu /></el-icon>
        </button>

        <template v-if="currentCourseId">
          <header class="editor-header">
            <div class="course-title">
              <span class="title-text">{{ currentCourseName || '课件预览' }}</span>
            </div>
          </header>

          <div class="editor-body">
            <!-- 加载蒙层 -->
            <div v-if="loadingDetail" class="status-mask">
               <el-icon class="is-loading" :size="32" color="#2196F3"><Loading /></el-icon>
               <p style="margin-top:12px; color:#5c626e; font-weight: 500;">正在获取课件详情...</p>
            </div>

            <!-- 编辑器 -->
            <Step2_Editor
              v-else
              :pdf-source="pdfSource"
              v-model:slides="slideData"
              :course-id="currentCourseId"
              v-model:currentSlide="currentEditIndex"
            />
            
            <!-- 轮询状态提示 -->
            <div v-if="isPolling" class="polling-toast glass-toast">
              <el-icon class="is-loading" :size="16" color="#2196F3"><Loading /></el-icon>
              <span>{{ pollingStatus }}</span>
            </div>
          </div>
        </template>
        <div v-else class="empty-workspace">
          <el-empty description="请从左侧选择文件开始阅读" />
        </div>
      </main>
    </div>

    <Dashboard v-else-if="viewMode === 'dashboard'" @back="handleNavigation('workbench')" />

    <!-- 自动保存提示 -->
    <div class="auto-save-toast glass-toast" :class="{ show: saveStatus !== 'idle' }">
<el-icon v-if="saveStatus === 'saving'" class="is-loading" color="#2196F3"><Loading /></el-icon>
      <el-icon v-if="saveStatus === 'synced'" color="#2196F3"><CircleCheck /></el-icon>
      <el-icon v-if="saveStatus === 'error'" color="#f56c6c"><CircleClose /></el-icon>
      <span>{{ saveStatusText }}</span>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted, onUnmounted, nextTick } from 'vue'
import { Plus, Loading, Search, CircleCheck, CircleClose, Document, Menu } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'


import TopHeader from './components/TopHeader.vue'
import Step2_Editor from './components/Editor.vue'
import Dashboard from './Dashboard.vue'
import { listMyCourses, uploadCourse, getCourseDetail, updateCourseScript } from '@/api/course'

const viewMode = ref('workbench')
const courseList = ref([])
const loadingList = ref(false)
const searchKeyword = ref('')
const currentCourseId = ref(null)
const currentCourseName = ref('')
const pdfSource = ref(null)
const slideData = ref([])
const currentEditIndex = ref(0)
const isUploading = ref(false)

// 移动端抽屉状态
const sidebarDrawerVisible = ref(false)
const isMobile = ref(false)

// 桌面端课件列表抽屉状态
const courseListDrawerVisible = ref(false)

// 状态控制
const isPolling = ref(false)
const loadingDetail = ref(false) 
const pollingStatus = ref('等待响应...')
let pollingTimer = null
const isGeneratingAudio = ref(false)
let audioCheckTimer = null
const saveStatus = ref('idle')
let autoSaveTimer = null
let isSystemUpdating = false 

const saveStatusText = computed(() => {
  const map = { saving: '正在保存...', synced: '已同步到云端', error: '保存失败' }
  return map[saveStatus.value] || ''
})

// 监听数据变化自动保存
watch(() => slideData.value, (newVal, oldVal) => {
  if (isSystemUpdating) {
    console.log('系统更新中，跳过保存')
    return
  }
  if (!currentCourseId.value || !newVal || newVal.length === 0) {
    console.log('无效数据，跳过保存')
    return
  }
  
  const hasContent = newVal.some(item => item.script && item.script.trim().length > 0)
  if (!hasContent) {
    console.log('无内容，跳过保存')
    return
  }
  
  console.log('检测到内容变化，准备保存...')
  saveStatus.value = 'saving'
  if (autoSaveTimer) clearTimeout(autoSaveTimer)
  
  autoSaveTimer = setTimeout(async () => {
    try {
      const scriptsToSave = slideData.value.map(item => ({ page: item.page, content: item.script }))
      console.log('开始保存脚本:', scriptsToSave)
      await updateCourseScript(currentCourseId.value, scriptsToSave)
      console.log('保存成功')
      saveStatus.value = 'synced'
      setTimeout(() => { if(saveStatus.value === 'synced') saveStatus.value = 'idle' }, 2000)
      
      isSystemUpdating = true
      slideData.value.forEach(item => item.audioUrl = '') 
      nextTick(() => { isSystemUpdating = false })

      isGeneratingAudio.value = true
      waitForAudioGeneration(currentCourseId.value)
    } catch (error) {
      console.error('保存失败:', error)
      saveStatus.value = 'error'
      ElMessage.error('保存失败: ' + (error.message || '未知错误'))
      setTimeout(() => { if(saveStatus.value === 'error') saveStatus.value = 'idle' }, 2000)
    }
  }, 1500)
}, { deep: true })

const filteredList = computed(() => {
  if (!searchKeyword.value) return courseList.value
  return courseList.value.filter(item =>
    item.courseName.toLowerCase().includes(searchKeyword.value.toLowerCase())
  )
})

onMounted(() => fetchCourseList())

const fetchCourseList = async () => {
  loadingList.value = true
  try {
    const res = await listMyCourses()
    courseList.value = res.data || []
  } catch (error) { console.error(error) }
  finally { loadingList.value = false }
}

const isPdfName = (name = '') => String(name).toLowerCase().endsWith('.pdf')
const isPptxName = (name = '') => String(name).toLowerCase().endsWith('.pptx')

const handleFileUpload = async (file) => {
  const raw = file?.raw
  if (!raw) return

  const maxSize = 100 * 1024 * 1024
  if (raw.size > maxSize) {
    ElMessage.error('文件超过 100MB，无法上传，请压缩后重试')
    return
  }

  isUploading.value = true
  try {
    const res = await uploadCourse(raw)
    const parseId = res.data?.parseId
    await fetchCourseList()
    const newCourse = courseList.value.find(c => c.parseId === parseId)

    if (newCourse) {
      const localPreviewThreshold = 20 * 1024 * 1024
      if (raw.size > localPreviewThreshold || !isPdfName(raw.name)) {
        await selectCourse(newCourse)
        ElMessage.success('上传成功，后台解析中...')
      } else {
        await selectCourse(newCourse, raw)
        ElMessage.success('上传成功')
      }
    } else {
      ElMessage.success('上传成功，解析任务已提交')
    }
  } catch (error) {
    ElMessage.error('上传失败')
  }
  finally { isUploading.value = false }
}

const selectCourse = async (courseRow, rawFile = null) => {
  currentCourseId.value = courseRow.id
  currentCourseName.value = courseRow.courseName
  currentEditIndex.value = 0
  
  isSystemUpdating = true
  slideData.value = [] 
  nextTick(() => { isSystemUpdating = false })

  if (pollingTimer) clearInterval(pollingTimer)
  if (audioCheckTimer) clearInterval(audioCheckTimer)
  isPolling.value = false
  isGeneratingAudio.value = false
  saveStatus.value = 'idle'
  
  if (rawFile) {
    if (isPdfName(rawFile.name) || isPptxName(rawFile.name)) {
      pdfSource.value = URL.createObjectURL(rawFile)
    } else {
      pdfSource.value = null
      ElMessage.info('PPT 正在后台转换为可预览格式，请稍候...')
    }
    slideData.value = []
    isSystemUpdating = false
    startPolling(courseRow.id)
    return
  }

  loadingDetail.value = true
  try {
    const res = await getCourseDetail(courseRow.id)
    const detailData = res.data
    
    if (detailData.fileUrl && (isPdfName(detailData.fileUrl) || isPptxName(detailData.fileUrl))) {
      pdfSource.value = `/api/v1/lesson/files/${detailData.fileUrl}`
    } else {
      pdfSource.value = null
    }

    const status = detailData.status
    
    if (status === 0 || status === 1) {
      startPolling(courseRow.id)
    } else if (status === 2) {
      parseData(detailData.aiScript, detailData.audioScript)
      isGeneratingAudio.value = true
      waitForAudioGeneration(courseRow.id)
    } else if (status === 3) {
      parseData(detailData.aiScript, detailData.audioScript)
      isGeneratingAudio.value = false
    } else if (status === 9) {
      if (detailData.aiScript && detailData.aiScript.length > 0) {
        parseData(detailData.aiScript, detailData.audioScript)
      } else {
        ElMessage.error('该课件解析失败，请尝试重新上传')
      }
    }

  } catch (error) {
    console.error(error)
    ElMessage.error('获取课件详情失败')
  } finally {
    loadingDetail.value = false
  }
}

// 移动端相关方法
const toggleSidebar = () => {
  sidebarDrawerVisible.value = !sidebarDrawerVisible.value
}

const selectCourseAndClose = async (item) => {
  await selectCourse(item)
  sidebarDrawerVisible.value = false
}

// 检测屏幕尺寸
const checkScreenSize = () => {
  isMobile.value = window.innerWidth <= 768
}

onMounted(() => {
  checkScreenSize()
  window.addEventListener('resize', checkScreenSize)
  fetchCourseList()
})

onUnmounted(() => {
  window.removeEventListener('resize', checkScreenSize)
  if (pollingTimer) clearInterval(pollingTimer)
  if (audioCheckTimer) clearInterval(audioCheckTimer)
  if (autoSaveTimer) clearTimeout(autoSaveTimer)
})

const startPolling = (courseId) => {
  isPolling.value = true
  pollingStatus.value = 'AI 引擎启动中...'
  pollingTimer = setInterval(async () => {
    if (currentCourseId.value !== courseId) { clearInterval(pollingTimer); return }
    try {
      const res = await getCourseDetail(courseId)
      const course = res.data
      if (course.fileUrl && (isPdfName(course.fileUrl) || isPptxName(course.fileUrl))) {
        pdfSource.value = `/api/v1/lesson/files/${course.fileUrl}`
      }
      
      if (course.aiScript && course.aiScript.length > 0) {
        parseData(course.aiScript, course.audioScript || [])
        if (course.status >= 2) {
          pollingStatus.value = '正在合成语音...'
        } else {
          pollingStatus.value = `正在生成讲稿... (${course.aiScript.length}页已完成)`
        }
      }
      
      if (course.status === 2) {
        clearInterval(pollingTimer)
        isPolling.value = false
        parseData(course.aiScript, course.audioScript)
        isGeneratingAudio.value = true
        waitForAudioGeneration(courseId)
      } else if (course.status === 3) {
        clearInterval(pollingTimer)
        isPolling.value = false
        parseData(course.aiScript, course.audioScript)
        isGeneratingAudio.value = false
      } else if (course.status === 9) {
        clearInterval(pollingTimer)
        isPolling.value = false
        ElMessage.error('解析失败')
      }
    } catch (err) { console.error(err) }
  }, 2000)
}

const waitForAudioGeneration = (courseId) => {
  if(audioCheckTimer) clearInterval(audioCheckTimer)
  audioCheckTimer = setInterval(async () => {
    if (currentCourseId.value !== courseId) { clearInterval(audioCheckTimer); return }
    try {
      const res = await getCourseDetail(courseId)
      const data = res.data
      
      let audioReady = false
      if (data.status === 3) audioReady = true
      else if (data.audioScript && Array.isArray(data.audioScript) && data.audioScript.length > 0) {
         audioReady = data.audioScript.some(s => s.audioUrl && s.audioUrl.length > 5)
      }

      if (audioReady) {
        clearInterval(audioCheckTimer)
        isGeneratingAudio.value = false
        parseData(data.aiScript, data.audioScript)
        ElMessage.success('语音合成已就绪')
      }
    } catch (e) {
      clearInterval(audioCheckTimer)
    }
  }, 3000)
}

const parseData = (scriptData, audioData) => {
  try {
    const textArr = typeof scriptData === 'string' ? JSON.parse(scriptData) : (scriptData || [])
    const audioArr = typeof audioData === 'string' ? JSON.parse(audioData) : (audioData || [])
    
    if (!Array.isArray(textArr) || textArr.length === 0) return

    let audioMap = {}
    if (Array.isArray(audioArr)) {
      audioArr.forEach(item => {
        if (item.page) audioMap[item.page] = item.audioUrl
      })
    }

    isSystemUpdating = true
    slideData.value = textArr.map(item => ({
      page: item.page,
      title: `第 ${item.page} 页`,
      script: item.content || '',
      audioUrl: audioMap[item.page] || '', 
      quiz: null
    }))
    nextTick(() => { isSystemUpdating = false })
  } catch (e) { console.error('Data parse error', e) }
}

const formatDate = (dateStr) => {
  if (!dateStr) return '未知'
  return dateStr.replace('T', ' ').split('.')[0]
}

const handleNavigation = (target) => { viewMode.value = target }

onUnmounted(() => {
  if (pollingTimer) clearInterval(pollingTimer)
  if (audioCheckTimer) clearInterval(audioCheckTimer)
  if (autoSaveTimer) clearTimeout(autoSaveTimer)
})
</script>

<style scoped>
/* 全局背景：浅蓝色企业风格 */
.teacher-app { 
  position: fixed;
  inset: 0;
  width: 100%;
  height: 100vh;
  display: flex;
  flex-direction: column;
  background: linear-gradient(135deg, #E3F2FD 0%, #F5F9FF 50%, #F0F5FF 100%);
}

.main-viewport { 
  flex: 1;
  display: flex;
  overflow: hidden;
  padding: 16px;
  gap: 16px;
}

/* 玻璃拟态面板通用样式 */
.glass-panel {
  background: rgba(255, 255, 255, 0.92) !important;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(33, 150, 243, 0.2);
  border-radius: 12px;
  box-shadow: 0 4px 16px rgba(33, 150, 243, 0.1);
}

.glass-item {
  background: rgba(255, 255, 255, 0.95);
  border: 1px solid rgba(33, 150, 243, 0.15);
  border-radius: 8px;
  transition: all 0.3s;
}

.glass-item:hover {
  background: rgba(255, 255, 255, 1);
  box-shadow: 0 4px 12px rgba(33, 150, 243, 0.12);
  border-color: rgba(33, 150, 243, 0.25);
}

/* 侧边栏 */
.left-sidebar { 
  width: 280px; 
  display: flex; 
  flex-direction: column; 
  flex-shrink: 0; 
  padding: 20px 12px; 
  overflow-y: auto;
}

.upload-section { margin-bottom: 20px; padding: 0 8px; }

.full-width-upload, .full-width-upload :deep(.el-upload) { width: 100%; display: block; }

.upload-btn { 
  width: 100%;
  height: 44px;
  border-radius: 8px;
  font-weight: 600;
  font-size: 14px;
  background: linear-gradient(90deg, #2196F3 0%, #64B5F6 100%) !important; 
  border: none !important;
  color: #FFFFFF !important;
  transition: all 0.3s;
  box-shadow: 0 4px 12px rgba(33, 150, 243, 0.28);
}

.upload-btn:hover {
  box-shadow: 0 6px 18px rgba(33, 150, 243, 0.35);
  transform: translateY(-2px);
}

.search-box { margin-bottom: 20px; padding: 0 8px; }

.glass-search :deep(.el-input__wrapper) {
  border-radius: 8px;
  background: #FFFFFF !important;
  box-shadow: 0 0 0 1px rgba(33, 150, 243, 0.2) inset !important;
  backdrop-filter: blur(2px);
  transition: all 0.3s;
}

.glass-search :deep(.el-input__wrapper.is-focus) {
  box-shadow: 0 0 0 1.5px #2196F3 inset !important;
  background: #F8FBFE !important;
}

.list-header {
  font-size: 13px;
  color: #1976D2;
  margin-bottom: 12px;
  padding: 0 12px;
  font-weight: 600;
}

.file-list { 
  flex: 1; 
  overflow-y: auto; 
  display: flex; 
  flex-direction: column; 
  gap: 10px; 
  padding: 4px 8px; 
}

/* 课件列表项 */
.file-list-item { 
  position: relative;
  padding: 14px;
  cursor: pointer;
  transition: all 0.3s;
  overflow: hidden;
  border-radius: 8px;
}

.file-list-item:hover {
  transform: translateY(-2px);
  background: rgba(33, 150, 243, 0.08);
  box-shadow: 0 4px 12px rgba(33, 150, 243, 0.12);
  border-color: #2196F3;
}

.file-list-item.active {
  border-color: #2196F3;
  background: rgba(33, 150, 243, 0.1);
  box-shadow: 0 4px 16px rgba(33, 150, 243, 0.2);
}

.active-bar {
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
  width: 4px;
  height: 28px;
  background: linear-gradient(180deg, #2196F3 0%, #64B5F6 100%);
  border-radius: 0 2px 2px 0;
  box-shadow: 2px 0 8px rgba(33, 150, 243, 0.35);
}

.file-card-content { 
  display: flex;
  align-items: center;
  gap: 12px;
}

.file-icon-wrapper {
  flex-shrink: 0;
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #2196F3;
  background: rgba(33, 150, 243, 0.1);
  border-radius: 8px;
}

.file-text-info { 
  flex: 1;
  overflow: hidden;
}

.file-name {
  font-size: 14px;
  color: #1565C0;
  font-weight: 700;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  margin-bottom: 4px;
}

.file-date {
  font-size: 11px;
  color: #64B5F6;
  font-weight: 500;
}

/* 主区域编辑器 */
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.editor-header {
  height: 60px;
  border-bottom: 1px solid rgba(33, 150, 243, 0.15);
  display: flex;
  align-items: center;
  padding: 0 24px;
  position: relative;
}

.title-text {
  font-weight: 700;
  color: #1565C0;
  font-size: 16px;
}

.editor-body {
  flex: 1;
  overflow: hidden;
  position: relative;
}

.status-mask {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
}

.empty-workspace {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
}

/* 浮动提示：企业风格 */
.glass-toast {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(8px);
  border: 1px solid rgba(33, 150, 243, 0.2);
  color: #1976D2;
  font-weight: 600;
  box-shadow: 0 4px 16px rgba(33, 150, 243, 0.15);
  border-radius: 8px;
}

.polling-toast {
  position: absolute;
  top: 20px;
  right: 20px;
  padding: 12px 16px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  gap: 8px;
  z-index: 100;
  font-size: 13px;
}

.auto-save-toast {
  position: fixed;
  bottom: 20px;
  right: 20px;
  padding: 10px 16px;
  border-radius: 8px;
  font-size: 13px;
  display: flex;
  align-items: center;
  gap: 8px;
  z-index: 9999;
  opacity: 0;
  transform: translateY(10px);
  transition: all 0.3s;
  pointer-events: none;
}

.auto-save-toast.show {
  opacity: 1;
  transform: translateY(0);
}

/* 响应式移动端适配 */
@media screen and (max-width: 768px) {
  .main-viewport { 
    flex-direction: row;
    overflow: hidden;
  }
  .sidebar-desktop {
    display: none;
  }
  .main-content { 
    width: 100%; 
    flex: 1; 
    position: relative;
  }
  .mobile-menu-btn {
    display: flex;
  }
}

@media screen and (min-width: 769px) {
  .sidebar-desktop {
    display: flex;
  }
  .sidebar-drawer {
    display: none;
  }
  .mobile-menu-btn {
    display: none;
  }
}

/* 移动端菜单按钮 */
.mobile-menu-btn {
  position: absolute;
  top: 50%;
  left: 16px;
  transform: translateY(-50%);
  z-index: 50;
  background: rgba(255, 255, 255, 0.95);
  border: none;
  border-radius: 8px;
  padding: 8px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition: all 0.3s;
  color: #2196F3;
}

.mobile-menu-btn:hover {
  background: rgba(33, 150, 243, 0.1);
  transform: scale(1.05);
}

/* 抽屉容器 */
.sidebar-drawer :deep(.el-drawer__header) {
  background: linear-gradient(90deg, #E3F2FD 0%, #F5F9FF 100%);
  border-bottom: 1px solid rgba(33, 150, 243, 0.2);
  padding: 12px 16px;
}

.sidebar-drawer :deep(.el-drawer__title) {
  color: #1565C0;
  font-weight: 600;
  font-size: 14px;
}

.sidebar-drawer :deep(.el-drawer__close) {
  color: #2196F3;
}

.drawer-content {
  padding: 12px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  height: 100%;
}

.drawer-file-list {
  flex: 1;
  overflow-y: auto;
  gap: 8px;
  padding: 4px 0;
}

.drawer-file-list .file-list-item {
  padding: 10px;
  margin-bottom: 0;
}

/* 滚动条美化 */
::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-thumb { background: rgba(33, 150, 243, 0.3); border-radius: 4px; }
::-webkit-scrollbar-track { background: transparent; }
</style>
