<template>
  <div class="dashboard-container">
    <header class="dashboard-header">
      <h2><el-icon><PieChart /></el-icon> 学情洞察看板</h2>
      <el-button @click="$emit('back')">返回创作</el-button>
    </header>

    <div class="chart-grid">
      <!-- 掌握度分布 -->
      <div class="chart-card">
        <h3>全班掌握度热力分布</h3>
        <div class="mock-heatmap">
          <div v-for="i in 15" :key="i" class="heat-box" :style="{ opacity: Math.random() + 0.2 }">
            P{{ i }}
          </div>
        </div>
        <p class="chart-desc">注：第 8 页和第 12 页学生停留及提问次数显著偏高</p>
      </div>

      <!-- 提问高频词 -->
      <div class="chart-card">
        <h3>学生提问关键词云</h3>
        <div class="mock-word-cloud">
          <span style="font-size: 24px; color: #0077ff">Transformer</span>
          <span style="font-size: 18px">Attention</span>
          <span style="font-size: 20px; color: #67c23a">Encoder</span>
          <span style="font-size: 14px">QKV</span>
          <span style="font-size: 16px; color: #f56c6c">维度对齐</span>
        </div>
      </div>
    </div>

    <!-- AI 建议 -->
    <div class="ai-suggestion">
      <el-alert title="AI 教学优化建议" type="warning" show-icon :closable="false">
        系统监测到 60% 的学生在“编码器结构”章节产生困惑，建议教师针对第 8 页内容重录讲解或增加随堂练习。
      </el-alert>
    </div>
  </div>
</template>

<script setup>
import { PieChart } from '@element-plus/icons-vue'
</script>

<style scoped>
.dashboard-container { padding: 30px; background: #f5f7fa; height: 100%; overflow-y: auto; }
.dashboard-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
.chart-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; }
.chart-card { background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 12px rgba(0,0,0,0.05); }
.chart-card h3 { font-size: 16px; margin-bottom: 20px; color: #333; }
.mock-heatmap { display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; }
.heat-box { background: #0077ff; color: #fff; height: 50px; display: flex; align-items: center; justify-content: center; border-radius: 4px; font-size: 12px; }
.mock-word-cloud { height: 170px; display: flex; flex-wrap: wrap; align-items: center; justify-content: center; gap: 15px; }
.chart-desc { font-size: 12px; color: #999; margin-top: 15px; }
.ai-suggestion { margin-top: 20px; }
</style>