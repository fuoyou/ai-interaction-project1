<template>
  <div>
    <header class="header">
      <!-- 左侧 Logo 区域 -->
      <div class="header-left" @click="$emit('nav', 'workbench')">
        <el-icon :size="20" color="#2196F3"><Monitor /></el-icon>
        <span class="logo-text hide-on-mobile">AI 智课创作中心</span>
      </div>

      <!-- 右侧导航与用户区 -->
      <div class="header-right">
        <el-divider direction="vertical" class="custom-divider hide-on-mobile" />

        <!-- 课件列表按钮 -->
        <el-button 
          type="primary" 
          plain 
          round 
          size="small" 
          class="course-list-btn hide-on-mobile"
          @click="$emit('showCourseList')"
        >
          <el-icon class="el-icon--left"><DocumentCopy /></el-icon>
          课件列表
        </el-button>

        <el-divider direction="vertical" class="custom-divider hide-on-mobile" />

        <!-- 用户头像下拉菜单-->
        <el-dropdown trigger="click" @command="handleCommand">
          <div class="user-profile">
            <el-avatar
              :size="28"
              :src="userInfo.avatar || 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'"
            />
            <span class="user-name hide-on-mobile">{{ userInfo.nickname || userInfo.username || '教师' }}</span>
            <el-icon class="arrow-icon hide-on-mobile"><ArrowDown /></el-icon>
          </div>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="profile">个人中心</el-dropdown-item>
              <el-dropdown-item command="logout" divided>退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </header>

    <!-- 个人中心弹窗-->
    <el-dialog 
      v-model="showProfileDialog" 
      title="个人中心" 
      :width="dialogWidth" 
      center 
      align-center
      class="glass-dialog"
    >
      <div class="profile-dialog-content">
        <div class="avatar-upload-section">
          <el-avatar :size="70" :src="profileForm.avatar || 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'" />
          <p class="role-badge">当前身份：教师</p>
        </div>

        <el-form :model="profileForm" label-width="80px" label-position="left">
          <el-form-item label="登录账号">
            <el-input v-model="profileForm.username" disabled class="glass-input" />
          </el-form-item>
          <el-form-item label="用户昵称">
            <el-input v-model="profileForm.nickname" placeholder="请输入您的昵称" class="glass-input" />
          </el-form-item>
          <el-form-item label="头像地址">
            <el-input v-model="profileForm.avatar" placeholder="请输入头像图片URL地址" class="glass-input" />
          </el-form-item>
        </el-form>
      </div>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="showProfileDialog = false" class="glass-btn">取消</el-button>
          <el-button type="primary" :loading="saveLoading" @click="saveProfile" class="glass-btn-primary">确认修改</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, computed, onUnmounted } from 'vue'
import { Monitor, ArrowDown, DocumentCopy } from '@element-plus/icons-vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { updateUserProfile } from '@/api/user'

const emit = defineEmits(['nav'])
const router = useRouter()

// --- 响应式适配 ---
const isMobile = ref(window.innerWidth <= 768)
const checkMobile = () => { isMobile.value = window.innerWidth <= 768 }
const dialogWidth = computed(() => isMobile.value ? '90%' : '420px')

// --- 用户状态管理 ---
const userInfo = ref({ nickname: '', avatar: '', username: '' })
const showProfileDialog = ref(false)
const saveLoading = ref(false)
const profileForm = reactive({ username: '', nickname: '', avatar: '' })

// 初始化加载用户信息
onMounted(() => {
  window.addEventListener('resize', checkMobile)
  const cachedUser = localStorage.getItem('userInfo')
  if (cachedUser) {
    userInfo.value = JSON.parse(cachedUser)
  }
})

onUnmounted(() => {
  window.removeEventListener('resize', checkMobile)
})

// --- 事件处理 ---
const handleCommand = (command) => {
  if (command === 'logout') {
    handleLogout()
  } else if (command === 'profile') {
    openProfile()
  }
}

const handleLogout = () => {
  ElMessageBox.confirm('确定要退出登录吗？', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    localStorage.clear()
    router.push('/login')
    ElMessage.success('已安全退出')
  }).catch(() => {})
}

// --- 个人中心逻辑 ---
const openProfile = () => {
  profileForm.username = userInfo.value.username || '未登录'
  profileForm.nickname = userInfo.value.nickname
  profileForm.avatar = userInfo.value.avatar
  showProfileDialog.value = true
}

const saveProfile = async () => {
  if (!profileForm.nickname.trim()) return ElMessage.warning('昵称不能为空')

  saveLoading.value = true
  try {
    await updateUserProfile({
      username: userInfo.value.username,
      nickname: profileForm.nickname,
      avatar: profileForm.avatar
    })

    userInfo.value.nickname = profileForm.nickname
    userInfo.value.avatar = profileForm.avatar
    localStorage.setItem('userInfo', JSON.stringify(userInfo.value))

    ElMessage.success('个人信息已更新')
    showProfileDialog.value = false
  } catch (error) {
    console.error("保存失败", error)
  } finally {
    saveLoading.value = false
  }
}
</script>

<style scoped>
/* 1. 头部容器：浅蓝色企业风格 */
.header {
  height: 50px; 
  background: linear-gradient(90deg, #FFFFFF 0%, #F0F5FF 100%); 
  backdrop-filter: blur(4px);
  border-bottom: 1px solid rgba(33, 150, 243, 0.15);
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 20px;
  flex-shrink: 0;
  z-index: 200;
  box-shadow: 0 2px 6px rgba(33, 150, 243, 0.08);
}

.header-left {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  transition: all 0.2s;
}
.header-left:hover { 
  opacity: 0.9;
  transform: translateY(-1px);
}

.logo-text {
  font-size: 16px;
  font-weight: 600;
  color: #1976D2;
  letter-spacing: 0.5px;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 15px;
}

.custom-divider {
  height: 16px;
  border-color: rgba(33, 150, 243, 0.2);
}

/* 用户区域：浅蓝色主题 */
.user-profile {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  outline: none;
  padding: 4px 12px;
  border-radius: 6px;
  transition: all 0.3s;
}

.user-profile:hover {
  background: rgba(33, 150, 243, 0.1);
  box-shadow: 0 2px 4px rgba(33, 150, 243, 0.1);
}

.user-name {
  font-size: 14px;
  color: #1976D2;
  font-weight: 500;
}

.arrow-icon {
  font-size: 12px;
  color: #64B5F6;
}

/* 2. 个人中心内容样式 */
.profile-dialog-content { 
  display: flex; 
  flex-direction: column; 
  align-items: center; 
  padding: 10px 0; 
}

.avatar-upload-section { 
  text-align: center; 
  margin-bottom: 25px; 
}

.role-badge { 
  font-size: 12px;
  color: #1976D2;
  margin-top: 8px;
  background: rgba(33, 150, 243, 0.1);
  padding: 4px 12px;
  border-radius: 6px;
  border: 1px solid rgba(33, 150, 243, 0.25);
}

/* 3. 弹窗及控件的企业风格 */
:deep(.glass-dialog .el-dialog) {
  background: linear-gradient(135deg, #F5FAFE 0%, #F0F5FF 100%) !important;
  backdrop-filter: blur(10px) !important;
  border-radius: 8px !important;
  border: 1px solid rgba(33, 150, 243, 0.2) !important;
  box-shadow: 0 8px 24px rgba(33, 150, 243, 0.12) !important;
}

:deep(.glass-input .el-input__wrapper) { 
  background: #FFFFFF !important;
  backdrop-filter: blur(2px);
  border-radius: 6px !important;
  box-shadow: 0 0 0 1px rgba(33, 150, 243, 0.25) inset !important;
  transition: all 0.3s;
}

:deep(.glass-input .el-input__wrapper.is-focus) {
  box-shadow: 0 0 0 1px #2196F3 inset !important;
  background: #FFFFFF !important;
  box-shadow: 0 2px 8px rgba(33, 150, 243, 0.15) !important;
}

.dialog-footer {
  display: flex;
  justify-content: center;
  gap: 15px;
}

.glass-btn {
  background: #FFFFFF !important;
  border: 1px solid rgba(33, 150, 243, 0.25) !important;
  color: #1976D2 !important;
  border-radius: 6px;
  transition: all 0.3s;
}

.glass-btn:hover {
  background: rgba(33, 150, 243, 0.08) !important;
  color: #1565C0 !important;
  border-color: #2196F3 !important;
}

.glass-btn-primary {
  background: linear-gradient(90deg, #2196F3 0%, #64B5F6 100%) !important;
  border: none !important;
  border-radius: 6px;
  box-shadow: 0 4px 12px rgba(33, 150, 243, 0.28) !important;
  transition: all 0.3s;
}

.glass-btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(33, 150, 243, 0.35) !important;
}

/* 4. 移动端响应式隐藏 */
@media screen and (max-width: 768px) {
  .hide-on-mobile {
    display: none !important;
  }
  .header {
    padding: 0 12px;
  }
  .header-right {
    gap: 8px;
  }
}
</style>
